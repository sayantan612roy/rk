var stats = {
    type: "GROUP",
name: "Global Information",
path: "",
pathFormatted: "group_missing-name-b06d1",
stats: {
    "name": "Global Information",
    "numberOfRequests": {
        "total": "1165",
        "ok": "1159",
        "ko": "6"
    },
    "minResponseTime": {
        "total": "5",
        "ok": "5",
        "ko": "60001"
    },
    "maxResponseTime": {
        "total": "60015",
        "ok": "42308",
        "ko": "60015"
    },
    "meanResponseTime": {
        "total": "1521",
        "ok": "1218",
        "ko": "60010"
    },
    "standardDeviation": {
        "total": "5473",
        "ok": "3508",
        "ko": "5"
    },
    "percentiles1": {
        "total": "1235",
        "ok": "1226",
        "ko": "60013"
    },
    "percentiles2": {
        "total": "1602",
        "ok": "1595",
        "ko": "60014"
    },
    "percentiles3": {
        "total": "2274",
        "ok": "2190",
        "ko": "60015"
    },
    "percentiles4": {
        "total": "38418",
        "ok": "12678",
        "ko": "60015"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 1122,
    "percentage": 96
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 37,
    "percentage": 3
},
    "group4": {
    "name": "failed",
    "count": 6,
    "percentage": 1
},
    "meanNumberOfRequestsPerSecond": {
        "total": "6.297",
        "ok": "6.265",
        "ko": "0.032"
    }
},
contents: {
"req_request-0-684d2": {
        type: "REQUEST",
        name: "request_0",
path: "request_0",
pathFormatted: "req_request-0-684d2",
stats: {
    "name": "request_0",
    "numberOfRequests": {
        "total": "10",
        "ok": "10",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1122",
        "ok": "1122",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1147",
        "ok": "1147",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1128",
        "ok": "1128",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "8",
        "ok": "8",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1134",
        "ok": "1134",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1135",
        "ok": "1135",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1142",
        "ok": "1142",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1146",
        "ok": "1146",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 10,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.054",
        "ok": "0.054",
        "ko": "-"
    }
}
    },"req_request-0-redir-e6ac5": {
        type: "REQUEST",
        name: "request_0 Redirect 1",
path: "request_0 Redirect 1",
pathFormatted: "req_request-0-redir-e6ac5",
stats: {
    "name": "request_0 Redirect 1",
    "numberOfRequests": {
        "total": "10",
        "ok": "9",
        "ko": "1"
    },
    "minResponseTime": {
        "total": "813",
        "ok": "813",
        "ko": "60009"
    },
    "maxResponseTime": {
        "total": "60009",
        "ok": "871",
        "ko": "60009"
    },
    "meanResponseTime": {
        "total": "6748",
        "ok": "830",
        "ko": "60009"
    },
    "standardDeviation": {
        "total": "17754",
        "ok": "17",
        "ko": "0"
    },
    "percentiles1": {
        "total": "840",
        "ok": "836",
        "ko": "60009"
    },
    "percentiles2": {
        "total": "861",
        "ok": "840",
        "ko": "60009"
    },
    "percentiles3": {
        "total": "33397",
        "ok": "859",
        "ko": "60009"
    },
    "percentiles4": {
        "total": "54687",
        "ok": "869",
        "ko": "60009"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 9,
    "percentage": 90
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 1,
    "percentage": 10
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.054",
        "ok": "0.049",
        "ko": "0.005"
    }
}
    },"req_request-0-redir-f42a7": {
        type: "REQUEST",
        name: "request_0 Redirect 2",
path: "request_0 Redirect 2",
pathFormatted: "req_request-0-redir-f42a7",
stats: {
    "name": "request_0 Redirect 2",
    "numberOfRequests": {
        "total": "9",
        "ok": "9",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "34310",
        "ok": "34310",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "42308",
        "ok": "42308",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "38314",
        "ok": "38314",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "2408",
        "ok": "2408",
        "ko": "-"
    },
    "percentiles1": {
        "total": "38911",
        "ok": "38911",
        "ko": "-"
    },
    "percentiles2": {
        "total": "40089",
        "ok": "40089",
        "ko": "-"
    },
    "percentiles3": {
        "total": "41538",
        "ok": "41538",
        "ko": "-"
    },
    "percentiles4": {
        "total": "42154",
        "ok": "42154",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 9,
    "percentage": 100
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.049",
        "ok": "0.049",
        "ko": "-"
    }
}
    },"req_223881-png-4b16d": {
        type: "REQUEST",
        name: "223881.png",
path: "223881.png",
pathFormatted: "req_223881-png-4b16d",
stats: {
    "name": "223881.png",
    "numberOfRequests": {
        "total": "19",
        "ok": "19",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "484",
        "ok": "484",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1834",
        "ok": "1834",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1073",
        "ok": "1073",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "416",
        "ok": "416",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1287",
        "ok": "1287",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1688",
        "ok": "1688",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1713",
        "ok": "1713",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1810",
        "ok": "1810",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 19,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.103",
        "ok": "0.103",
        "ko": "-"
    }
}
    },"req_request-69-74f38": {
        type: "REQUEST",
        name: "request_69",
path: "request_69",
pathFormatted: "req_request-69-74f38",
stats: {
    "name": "request_69",
    "numberOfRequests": {
        "total": "9",
        "ok": "8",
        "ko": "1"
    },
    "minResponseTime": {
        "total": "602",
        "ok": "602",
        "ko": "60001"
    },
    "maxResponseTime": {
        "total": "60001",
        "ok": "1798",
        "ko": "60001"
    },
    "meanResponseTime": {
        "total": "7777",
        "ok": "1249",
        "ko": "60001"
    },
    "standardDeviation": {
        "total": "18469",
        "ok": "450",
        "ko": "0"
    },
    "percentiles1": {
        "total": "1797",
        "ok": "1642",
        "ko": "60001"
    },
    "percentiles2": {
        "total": "1798",
        "ok": "1787",
        "ko": "60001"
    },
    "percentiles3": {
        "total": "36720",
        "ok": "1798",
        "ko": "60001"
    },
    "percentiles4": {
        "total": "55345",
        "ok": "1798",
        "ko": "60001"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 8,
    "percentage": 89
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 1,
    "percentage": 11
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.049",
        "ok": "0.043",
        "ko": "0.005"
    }
}
    },"req_request-70-f2f97": {
        type: "REQUEST",
        name: "request_70",
path: "request_70",
pathFormatted: "req_request-70-f2f97",
stats: {
    "name": "request_70",
    "numberOfRequests": {
        "total": "9",
        "ok": "9",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "603",
        "ok": "603",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1699",
        "ok": "1699",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "947",
        "ok": "947",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "322",
        "ok": "322",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1067",
        "ok": "1067",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1142",
        "ok": "1142",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1484",
        "ok": "1484",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1656",
        "ok": "1656",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 9,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.049",
        "ok": "0.049",
        "ko": "-"
    }
}
    },"req_request-71-7ee1e": {
        type: "REQUEST",
        name: "request_71",
path: "request_71",
pathFormatted: "req_request-71-7ee1e",
stats: {
    "name": "request_71",
    "numberOfRequests": {
        "total": "9",
        "ok": "9",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "606",
        "ok": "606",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1070",
        "ok": "1070",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "851",
        "ok": "851",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "147",
        "ok": "147",
        "ko": "-"
    },
    "percentiles1": {
        "total": "925",
        "ok": "925",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1015",
        "ok": "1015",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1057",
        "ok": "1057",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1067",
        "ok": "1067",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 9,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.049",
        "ok": "0.049",
        "ko": "-"
    }
}
    },"req_js-key-aizasydy-0df17": {
        type: "REQUEST",
        name: "js?key=AIzaSyDyOIM2ppRp-uTc7XLdQ1Y3PE4FvrzvT7E",
path: "js?key=AIzaSyDyOIM2ppRp-uTc7XLdQ1Y3PE4FvrzvT7E",
pathFormatted: "req_js-key-aizasydy-0df17",
stats: {
    "name": "js?key=AIzaSyDyOIM2ppRp-uTc7XLdQ1Y3PE4FvrzvT7E",
    "numberOfRequests": {
        "total": "13",
        "ok": "13",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "295",
        "ok": "295",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1843",
        "ok": "1843",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1127",
        "ok": "1127",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "498",
        "ok": "498",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1402",
        "ok": "1402",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1600",
        "ok": "1600",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1818",
        "ok": "1818",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1838",
        "ok": "1838",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 13,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.07",
        "ok": "0.07",
        "ko": "-"
    }
}
    },"req_request-73-b1eb5": {
        type: "REQUEST",
        name: "request_73",
path: "request_73",
pathFormatted: "req_request-73-b1eb5",
stats: {
    "name": "request_73",
    "numberOfRequests": {
        "total": "9",
        "ok": "9",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1500",
        "ok": "1500",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1884",
        "ok": "1884",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1682",
        "ok": "1682",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "133",
        "ok": "133",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1815",
        "ok": "1815",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1841",
        "ok": "1841",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1870",
        "ok": "1870",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1881",
        "ok": "1881",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 9,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.049",
        "ok": "0.049",
        "ko": "-"
    }
}
    },"req_request-51-1f144": {
        type: "REQUEST",
        name: "request_51",
path: "request_51",
pathFormatted: "req_request-51-1f144",
stats: {
    "name": "request_51",
    "numberOfRequests": {
        "total": "9",
        "ok": "9",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1235",
        "ok": "1235",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1570",
        "ok": "1570",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1401",
        "ok": "1401",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "134",
        "ok": "134",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1541",
        "ok": "1541",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1553",
        "ok": "1553",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1564",
        "ok": "1564",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1569",
        "ok": "1569",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 9,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.049",
        "ok": "0.049",
        "ko": "-"
    }
}
    },"req_request-52-eab3a": {
        type: "REQUEST",
        name: "request_52",
path: "request_52",
pathFormatted: "req_request-52-eab3a",
stats: {
    "name": "request_52",
    "numberOfRequests": {
        "total": "9",
        "ok": "9",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1047",
        "ok": "1047",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1592",
        "ok": "1592",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1363",
        "ok": "1363",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "174",
        "ok": "174",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1555",
        "ok": "1555",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1579",
        "ok": "1579",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1589",
        "ok": "1589",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1591",
        "ok": "1591",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 9,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.049",
        "ok": "0.049",
        "ko": "-"
    }
}
    },"req_request-60-458f3": {
        type: "REQUEST",
        name: "request_60",
path: "request_60",
pathFormatted: "req_request-60-458f3",
stats: {
    "name": "request_60",
    "numberOfRequests": {
        "total": "9",
        "ok": "9",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "920",
        "ok": "920",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1614",
        "ok": "1614",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1412",
        "ok": "1412",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "206",
        "ok": "206",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1593",
        "ok": "1593",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1595",
        "ok": "1595",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1607",
        "ok": "1607",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1613",
        "ok": "1613",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 9,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.049",
        "ok": "0.049",
        "ko": "-"
    }
}
    },"req_request-64-69a30": {
        type: "REQUEST",
        name: "request_64",
path: "request_64",
pathFormatted: "req_request-64-69a30",
stats: {
    "name": "request_64",
    "numberOfRequests": {
        "total": "9",
        "ok": "9",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "789",
        "ok": "789",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1616",
        "ok": "1616",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1252",
        "ok": "1252",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "315",
        "ok": "315",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1470",
        "ok": "1470",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1570",
        "ok": "1570",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1608",
        "ok": "1608",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1614",
        "ok": "1614",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 9,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.049",
        "ok": "0.049",
        "ko": "-"
    }
}
    },"req_sidebarv2-js-ap-63600": {
        type: "REQUEST",
        name: "sidebarv2.js?apikey=5yglhv6ek2lhx5s4zhefpq",
path: "sidebarv2.js?apikey=5yglhv6ek2lhx5s4zhefpq",
pathFormatted: "req_sidebarv2-js-ap-63600",
stats: {
    "name": "sidebarv2.js?apikey=5yglhv6ek2lhx5s4zhefpq",
    "numberOfRequests": {
        "total": "19",
        "ok": "19",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "876",
        "ok": "876",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "2276",
        "ok": "2276",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1464",
        "ok": "1464",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "417",
        "ok": "417",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1736",
        "ok": "1736",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1902",
        "ok": "1902",
        "ko": "-"
    },
    "percentiles3": {
        "total": "2046",
        "ok": "2046",
        "ko": "-"
    },
    "percentiles4": {
        "total": "2230",
        "ok": "2230",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 19,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.103",
        "ok": "0.103",
        "ko": "-"
    }
}
    },"req_all-css-889b5": {
        type: "REQUEST",
        name: "all.css",
path: "all.css",
pathFormatted: "req_all-css-889b5",
stats: {
    "name": "all.css",
    "numberOfRequests": {
        "total": "13",
        "ok": "13",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "425",
        "ok": "425",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1643",
        "ok": "1643",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1243",
        "ok": "1243",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "368",
        "ok": "368",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1435",
        "ok": "1435",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1637",
        "ok": "1637",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1640",
        "ok": "1640",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1642",
        "ok": "1642",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 13,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.07",
        "ok": "0.07",
        "ko": "-"
    }
}
    },"req_request-46-809be": {
        type: "REQUEST",
        name: "request_46",
path: "request_46",
pathFormatted: "req_request-46-809be",
stats: {
    "name": "request_46",
    "numberOfRequests": {
        "total": "9",
        "ok": "9",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1118",
        "ok": "1118",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1706",
        "ok": "1706",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1417",
        "ok": "1417",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "213",
        "ok": "213",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1658",
        "ok": "1658",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1675",
        "ok": "1675",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1695",
        "ok": "1695",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1704",
        "ok": "1704",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 9,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.049",
        "ok": "0.049",
        "ko": "-"
    }
}
    },"req_style-css-ver-a-78361": {
        type: "REQUEST",
        name: "style.css?ver=a9447bd6fcad109f78140a603b0758d0d8e4c85a",
path: "style.css?ver=a9447bd6fcad109f78140a603b0758d0d8e4c85a",
pathFormatted: "req_style-css-ver-a-78361",
stats: {
    "name": "style.css?ver=a9447bd6fcad109f78140a603b0758d0d8e4c85a",
    "numberOfRequests": {
        "total": "19",
        "ok": "19",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "161",
        "ok": "161",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "3876",
        "ok": "3876",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1759",
        "ok": "1759",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "1254",
        "ok": "1254",
        "ko": "-"
    },
    "percentiles1": {
        "total": "2780",
        "ok": "2780",
        "ko": "-"
    },
    "percentiles2": {
        "total": "2935",
        "ok": "2935",
        "ko": "-"
    },
    "percentiles3": {
        "total": "3339",
        "ok": "3339",
        "ko": "-"
    },
    "percentiles4": {
        "total": "3769",
        "ok": "3769",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 16,
    "percentage": 84
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 3,
    "percentage": 16
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.103",
        "ok": "0.103",
        "ko": "-"
    }
}
    },"req_style-min-css-v-0cc1b": {
        type: "REQUEST",
        name: "style.min.css?ver=5.9.3",
path: "style.min.css?ver=5.9.3",
pathFormatted: "req_style-min-css-v-0cc1b",
stats: {
    "name": "style.min.css?ver=5.9.3",
    "numberOfRequests": {
        "total": "19",
        "ok": "19",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "169",
        "ok": "169",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "721",
        "ok": "721",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "392",
        "ok": "392",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "166",
        "ok": "166",
        "ko": "-"
    },
    "percentiles1": {
        "total": "477",
        "ok": "477",
        "ko": "-"
    },
    "percentiles2": {
        "total": "570",
        "ok": "570",
        "ko": "-"
    },
    "percentiles3": {
        "total": "647",
        "ok": "647",
        "ko": "-"
    },
    "percentiles4": {
        "total": "706",
        "ok": "706",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 19,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.103",
        "ok": "0.103",
        "ko": "-"
    }
}
    },"req_borlabs-cookie--5535e": {
        type: "REQUEST",
        name: "borlabs-cookie_1_en.css?ver=2.2.49-15",
path: "borlabs-cookie_1_en.css?ver=2.2.49-15",
pathFormatted: "req_borlabs-cookie--5535e",
stats: {
    "name": "borlabs-cookie_1_en.css?ver=2.2.49-15",
    "numberOfRequests": {
        "total": "19",
        "ok": "19",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "158",
        "ok": "158",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "2069",
        "ok": "2069",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1078",
        "ok": "1078",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "767",
        "ok": "767",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1848",
        "ok": "1848",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1881",
        "ok": "1881",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1929",
        "ok": "1929",
        "ko": "-"
    },
    "percentiles4": {
        "total": "2041",
        "ok": "2041",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 19,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.103",
        "ok": "0.103",
        "ko": "-"
    }
}
    },"req_cropped-kerv-fa-a72f1": {
        type: "REQUEST",
        name: "cropped-kerv-favicon-32x32.png",
path: "cropped-kerv-favicon-32x32.png",
pathFormatted: "req_cropped-kerv-fa-a72f1",
stats: {
    "name": "cropped-kerv-favicon-32x32.png",
    "numberOfRequests": {
        "total": "19",
        "ok": "19",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "154",
        "ok": "154",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "2092",
        "ok": "2092",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1039",
        "ok": "1039",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "766",
        "ok": "766",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1694",
        "ok": "1694",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1841",
        "ok": "1841",
        "ko": "-"
    },
    "percentiles3": {
        "total": "2021",
        "ok": "2021",
        "ko": "-"
    },
    "percentiles4": {
        "total": "2078",
        "ok": "2078",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 19,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.103",
        "ok": "0.103",
        "ko": "-"
    }
}
    },"req_main-js-ver-a94-eedbb": {
        type: "REQUEST",
        name: "main.js?ver=a9447bd6fcad109f78140a603b0758d0d8e4c85a",
path: "main.js?ver=a9447bd6fcad109f78140a603b0758d0d8e4c85a",
pathFormatted: "req_main-js-ver-a94-eedbb",
stats: {
    "name": "main.js?ver=a9447bd6fcad109f78140a603b0758d0d8e4c85a",
    "numberOfRequests": {
        "total": "19",
        "ok": "19",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "157",
        "ok": "157",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "4103",
        "ok": "4103",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "2081",
        "ok": "2081",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "1569",
        "ok": "1569",
        "ko": "-"
    },
    "percentiles1": {
        "total": "3661",
        "ok": "3661",
        "ko": "-"
    },
    "percentiles2": {
        "total": "4014",
        "ok": "4014",
        "ko": "-"
    },
    "percentiles3": {
        "total": "4063",
        "ok": "4063",
        "ko": "-"
    },
    "percentiles4": {
        "total": "4095",
        "ok": "4095",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 12,
    "percentage": 63
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 7,
    "percentage": 37
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.103",
        "ok": "0.103",
        "ko": "-"
    }
}
    },"req_borlabs-cookie--1ad98": {
        type: "REQUEST",
        name: "borlabs-cookie-prioritize.min.js?ver=2.2.49",
path: "borlabs-cookie-prioritize.min.js?ver=2.2.49",
pathFormatted: "req_borlabs-cookie--1ad98",
stats: {
    "name": "borlabs-cookie-prioritize.min.js?ver=2.2.49",
    "numberOfRequests": {
        "total": "19",
        "ok": "19",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "155",
        "ok": "155",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "2070",
        "ok": "2070",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1016",
        "ok": "1016",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "748",
        "ok": "748",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1673",
        "ok": "1673",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1778",
        "ok": "1778",
        "ko": "-"
    },
    "percentiles3": {
        "total": "2019",
        "ok": "2019",
        "ko": "-"
    },
    "percentiles4": {
        "total": "2060",
        "ok": "2060",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 19,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.103",
        "ok": "0.103",
        "ko": "-"
    }
}
    },"req_request-63-a77d3": {
        type: "REQUEST",
        name: "request_63",
path: "request_63",
pathFormatted: "req_request-63-a77d3",
stats: {
    "name": "request_63",
    "numberOfRequests": {
        "total": "9",
        "ok": "9",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1374",
        "ok": "1374",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "2098",
        "ok": "2098",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1658",
        "ok": "1658",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "256",
        "ok": "256",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1914",
        "ok": "1914",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1976",
        "ok": "1976",
        "ko": "-"
    },
    "percentiles3": {
        "total": "2056",
        "ok": "2056",
        "ko": "-"
    },
    "percentiles4": {
        "total": "2090",
        "ok": "2090",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 9,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.049",
        "ok": "0.049",
        "ko": "-"
    }
}
    },"req_request-62-c1e7c": {
        type: "REQUEST",
        name: "request_62",
path: "request_62",
pathFormatted: "req_request-62-c1e7c",
stats: {
    "name": "request_62",
    "numberOfRequests": {
        "total": "9",
        "ok": "9",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "960",
        "ok": "960",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1818",
        "ok": "1818",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1451",
        "ok": "1451",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "284",
        "ok": "284",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1742",
        "ok": "1742",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1759",
        "ok": "1759",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1796",
        "ok": "1796",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1814",
        "ok": "1814",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 9,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.049",
        "ok": "0.049",
        "ko": "-"
    }
}
    },"req_request-72-a67b7": {
        type: "REQUEST",
        name: "request_72",
path: "request_72",
pathFormatted: "req_request-72-a67b7",
stats: {
    "name": "request_72",
    "numberOfRequests": {
        "total": "9",
        "ok": "8",
        "ko": "1"
    },
    "minResponseTime": {
        "total": "705",
        "ok": "705",
        "ko": "60015"
    },
    "maxResponseTime": {
        "total": "60015",
        "ok": "2216",
        "ko": "60015"
    },
    "meanResponseTime": {
        "total": "7863",
        "ok": "1344",
        "ko": "60015"
    },
    "standardDeviation": {
        "total": "18444",
        "ok": "494",
        "ko": "0"
    },
    "percentiles1": {
        "total": "1823",
        "ok": "1652",
        "ko": "60015"
    },
    "percentiles2": {
        "total": "2137",
        "ok": "1812",
        "ko": "60015"
    },
    "percentiles3": {
        "total": "36895",
        "ok": "2078",
        "ko": "60015"
    },
    "percentiles4": {
        "total": "55391",
        "ok": "2188",
        "ko": "60015"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 8,
    "percentage": 89
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 1,
    "percentage": 11
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.049",
        "ok": "0.043",
        "ko": "0.005"
    }
}
    },"req_223881-js-bfd94": {
        type: "REQUEST",
        name: "223881.js",
path: "223881.js",
pathFormatted: "req_223881-js-bfd94",
stats: {
    "name": "223881.js",
    "numberOfRequests": {
        "total": "19",
        "ok": "19",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "606",
        "ok": "606",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "2112",
        "ok": "2112",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1339",
        "ok": "1339",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "544",
        "ok": "544",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1812",
        "ok": "1812",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1890",
        "ok": "1890",
        "ko": "-"
    },
    "percentiles3": {
        "total": "2017",
        "ok": "2017",
        "ko": "-"
    },
    "percentiles4": {
        "total": "2093",
        "ok": "2093",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 19,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.103",
        "ok": "0.103",
        "ko": "-"
    }
}
    },"req_request-65-6c6ee": {
        type: "REQUEST",
        name: "request_65",
path: "request_65",
pathFormatted: "req_request-65-6c6ee",
stats: {
    "name": "request_65",
    "numberOfRequests": {
        "total": "9",
        "ok": "9",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "762",
        "ok": "762",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1823",
        "ok": "1823",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1211",
        "ok": "1211",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "286",
        "ok": "286",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1259",
        "ok": "1259",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1436",
        "ok": "1436",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1686",
        "ok": "1686",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1796",
        "ok": "1796",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 9,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.049",
        "ok": "0.049",
        "ko": "-"
    }
}
    },"req_request-66-3197b": {
        type: "REQUEST",
        name: "request_66",
path: "request_66",
pathFormatted: "req_request-66-3197b",
stats: {
    "name": "request_66",
    "numberOfRequests": {
        "total": "9",
        "ok": "9",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1704",
        "ok": "1704",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "2889",
        "ok": "2889",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "2127",
        "ok": "2127",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "317",
        "ok": "317",
        "ko": "-"
    },
    "percentiles1": {
        "total": "2270",
        "ok": "2270",
        "ko": "-"
    },
    "percentiles2": {
        "total": "2274",
        "ok": "2274",
        "ko": "-"
    },
    "percentiles3": {
        "total": "2643",
        "ok": "2643",
        "ko": "-"
    },
    "percentiles4": {
        "total": "2840",
        "ok": "2840",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 9,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.049",
        "ok": "0.049",
        "ko": "-"
    }
}
    },"req_request-61-92673": {
        type: "REQUEST",
        name: "request_61",
path: "request_61",
pathFormatted: "req_request-61-92673",
stats: {
    "name": "request_61",
    "numberOfRequests": {
        "total": "9",
        "ok": "8",
        "ko": "1"
    },
    "minResponseTime": {
        "total": "785",
        "ok": "785",
        "ko": "60010"
    },
    "maxResponseTime": {
        "total": "60010",
        "ok": "1822",
        "ko": "60010"
    },
    "meanResponseTime": {
        "total": "7739",
        "ok": "1206",
        "ko": "60010"
    },
    "standardDeviation": {
        "total": "18483",
        "ok": "314",
        "ko": "0"
    },
    "percentiles1": {
        "total": "1586",
        "ok": "1253",
        "ko": "60010"
    },
    "percentiles2": {
        "total": "1775",
        "ok": "1564",
        "ko": "60010"
    },
    "percentiles3": {
        "total": "36735",
        "ok": "1739",
        "ko": "60010"
    },
    "percentiles4": {
        "total": "55355",
        "ok": "1805",
        "ko": "60010"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 8,
    "percentage": 89
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 1,
    "percentage": 11
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.049",
        "ok": "0.043",
        "ko": "0.005"
    }
}
    },"req_request-67-cf809": {
        type: "REQUEST",
        name: "request_67",
path: "request_67",
pathFormatted: "req_request-67-cf809",
stats: {
    "name": "request_67",
    "numberOfRequests": {
        "total": "9",
        "ok": "9",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1630",
        "ok": "1630",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "2390",
        "ok": "2390",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1921",
        "ok": "1921",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "257",
        "ok": "257",
        "ko": "-"
    },
    "percentiles1": {
        "total": "2027",
        "ok": "2027",
        "ko": "-"
    },
    "percentiles2": {
        "total": "2221",
        "ok": "2221",
        "ko": "-"
    },
    "percentiles3": {
        "total": "2342",
        "ok": "2342",
        "ko": "-"
    },
    "percentiles4": {
        "total": "2380",
        "ok": "2380",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 9,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.049",
        "ok": "0.049",
        "ko": "-"
    }
}
    },"req_ws-tracking-js--2787c": {
        type: "REQUEST",
        name: "ws-tracking.js?v=1.77.1005",
path: "ws-tracking.js?v=1.77.1005",
pathFormatted: "req_ws-tracking-js--2787c",
stats: {
    "name": "ws-tracking.js?v=1.77.1005",
    "numberOfRequests": {
        "total": "19",
        "ok": "19",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "5",
        "ok": "5",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1381",
        "ok": "1381",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "588",
        "ok": "588",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "470",
        "ok": "470",
        "ko": "-"
    },
    "percentiles1": {
        "total": "975",
        "ok": "975",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1030",
        "ok": "1030",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1155",
        "ok": "1155",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1336",
        "ok": "1336",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 19,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.103",
        "ok": "0.103",
        "ko": "-"
    }
}
    },"req_request-49-5406f": {
        type: "REQUEST",
        name: "request_49",
path: "request_49",
pathFormatted: "req_request-49-5406f",
stats: {
    "name": "request_49",
    "numberOfRequests": {
        "total": "9",
        "ok": "9",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "785",
        "ok": "785",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1434",
        "ok": "1434",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1063",
        "ok": "1063",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "184",
        "ok": "184",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1133",
        "ok": "1133",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1214",
        "ok": "1214",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1354",
        "ok": "1354",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1418",
        "ok": "1418",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 9,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.049",
        "ok": "0.049",
        "ko": "-"
    }
}
    },"req_form-loader-js--0a4f6": {
        type: "REQUEST",
        name: "form-loader.js?v=1.77.1005",
path: "form-loader.js?v=1.77.1005",
pathFormatted: "req_form-loader-js--0a4f6",
stats: {
    "name": "form-loader.js?v=1.77.1005",
    "numberOfRequests": {
        "total": "19",
        "ok": "19",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "5",
        "ok": "5",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1569",
        "ok": "1569",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "708",
        "ok": "708",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "558",
        "ok": "558",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1142",
        "ok": "1142",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1248",
        "ok": "1248",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1437",
        "ok": "1437",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1543",
        "ok": "1543",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 19,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.103",
        "ok": "0.103",
        "ko": "-"
    }
}
    },"req_request-68-492ce": {
        type: "REQUEST",
        name: "request_68",
path: "request_68",
pathFormatted: "req_request-68-492ce",
stats: {
    "name": "request_68",
    "numberOfRequests": {
        "total": "9",
        "ok": "9",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1546",
        "ok": "1546",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "2226",
        "ok": "2226",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1816",
        "ok": "1816",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "248",
        "ok": "248",
        "ko": "-"
    },
    "percentiles1": {
        "total": "2007",
        "ok": "2007",
        "ko": "-"
    },
    "percentiles2": {
        "total": "2091",
        "ok": "2091",
        "ko": "-"
    },
    "percentiles3": {
        "total": "2180",
        "ok": "2180",
        "ko": "-"
    },
    "percentiles4": {
        "total": "2217",
        "ok": "2217",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 9,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.049",
        "ok": "0.049",
        "ko": "-"
    }
}
    },"req_request-50-b37d9": {
        type: "REQUEST",
        name: "request_50",
path: "request_50",
pathFormatted: "req_request-50-b37d9",
stats: {
    "name": "request_50",
    "numberOfRequests": {
        "total": "9",
        "ok": "9",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "902",
        "ok": "902",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1608",
        "ok": "1608",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1206",
        "ok": "1206",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "205",
        "ok": "205",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1256",
        "ok": "1256",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1418",
        "ok": "1418",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1548",
        "ok": "1548",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1596",
        "ok": "1596",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 9,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.049",
        "ok": "0.049",
        "ko": "-"
    }
}
    },"req_cropped-kerv-fa-d762a": {
        type: "REQUEST",
        name: "cropped-kerv-favicon-192x192.png",
path: "cropped-kerv-favicon-192x192.png",
pathFormatted: "req_cropped-kerv-fa-d762a",
stats: {
    "name": "cropped-kerv-favicon-192x192.png",
    "numberOfRequests": {
        "total": "13",
        "ok": "13",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "197",
        "ok": "197",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "630",
        "ok": "630",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "333",
        "ok": "333",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "122",
        "ok": "122",
        "ko": "-"
    },
    "percentiles1": {
        "total": "379",
        "ok": "379",
        "ko": "-"
    },
    "percentiles2": {
        "total": "441",
        "ok": "441",
        "ko": "-"
    },
    "percentiles3": {
        "total": "552",
        "ok": "552",
        "ko": "-"
    },
    "percentiles4": {
        "total": "614",
        "ok": "614",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 13,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.07",
        "ok": "0.07",
        "ko": "-"
    }
}
    },"req_kerv-birmingham-95423": {
        type: "REQUEST",
        name: "Kerv-Birmingham-Office.jpg",
path: "Kerv-Birmingham-Office.jpg",
pathFormatted: "req_kerv-birmingham-95423",
stats: {
    "name": "Kerv-Birmingham-Office.jpg",
    "numberOfRequests": {
        "total": "9",
        "ok": "9",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "549",
        "ok": "549",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1063",
        "ok": "1063",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "768",
        "ok": "768",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "177",
        "ok": "177",
        "ko": "-"
    },
    "percentiles1": {
        "total": "931",
        "ok": "931",
        "ko": "-"
    },
    "percentiles2": {
        "total": "958",
        "ok": "958",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1024",
        "ok": "1024",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1055",
        "ok": "1055",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 9,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.049",
        "ok": "0.049",
        "ko": "-"
    }
}
    },"req_kerv-birmingham-70239": {
        type: "REQUEST",
        name: "Kerv-Birmingham-Office2.jpg",
path: "Kerv-Birmingham-Office2.jpg",
pathFormatted: "req_kerv-birmingham-70239",
stats: {
    "name": "Kerv-Birmingham-Office2.jpg",
    "numberOfRequests": {
        "total": "9",
        "ok": "9",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "337",
        "ok": "337",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "2005",
        "ok": "2005",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "752",
        "ok": "752",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "488",
        "ok": "488",
        "ko": "-"
    },
    "percentiles1": {
        "total": "791",
        "ok": "791",
        "ko": "-"
    },
    "percentiles2": {
        "total": "957",
        "ok": "957",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1603",
        "ok": "1603",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1925",
        "ok": "1925",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 9,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.049",
        "ok": "0.049",
        "ko": "-"
    }
}
    },"req_kerv-animation--b65b8": {
        type: "REQUEST",
        name: "Kerv_Animation_2_Final_4K_ProRes-CORK-SCREW-0-00-02-23-scaled.jpg",
path: "Kerv_Animation_2_Final_4K_ProRes-CORK-SCREW-0-00-02-23-scaled.jpg",
pathFormatted: "req_kerv-animation--b65b8",
stats: {
    "name": "Kerv_Animation_2_Final_4K_ProRes-CORK-SCREW-0-00-02-23-scaled.jpg",
    "numberOfRequests": {
        "total": "9",
        "ok": "9",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "197",
        "ok": "197",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1139",
        "ok": "1139",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "666",
        "ok": "666",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "295",
        "ok": "295",
        "ko": "-"
    },
    "percentiles1": {
        "total": "830",
        "ok": "830",
        "ko": "-"
    },
    "percentiles2": {
        "total": "836",
        "ok": "836",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1019",
        "ok": "1019",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1115",
        "ok": "1115",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 9,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.049",
        "ok": "0.049",
        "ko": "-"
    }
}
    },"req_cloudthing-kerv-b0495": {
        type: "REQUEST",
        name: "cloudThing_KervDigital__3x.jpg",
path: "cloudThing_KervDigital__3x.jpg",
pathFormatted: "req_cloudthing-kerv-b0495",
stats: {
    "name": "cloudThing_KervDigital__3x.jpg",
    "numberOfRequests": {
        "total": "9",
        "ok": "9",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "625",
        "ok": "625",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1323",
        "ok": "1323",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "886",
        "ok": "886",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "248",
        "ok": "248",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1138",
        "ok": "1138",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1146",
        "ok": "1146",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1253",
        "ok": "1253",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1309",
        "ok": "1309",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 9,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.049",
        "ok": "0.049",
        "ko": "-"
    }
}
    },"req_new--solutions--c8161": {
        type: "REQUEST",
        name: "NEW-_Solutions-Digital-business.png",
path: "NEW-_Solutions-Digital-business.png",
pathFormatted: "req_new--solutions--c8161",
stats: {
    "name": "NEW-_Solutions-Digital-business.png",
    "numberOfRequests": {
        "total": "9",
        "ok": "9",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "259",
        "ok": "259",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1148",
        "ok": "1148",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "553",
        "ok": "553",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "240",
        "ok": "240",
        "ko": "-"
    },
    "percentiles1": {
        "total": "589",
        "ok": "589",
        "ko": "-"
    },
    "percentiles2": {
        "total": "601",
        "ok": "601",
        "ko": "-"
    },
    "percentiles3": {
        "total": "930",
        "ok": "930",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1104",
        "ok": "1104",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 9,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.049",
        "ok": "0.049",
        "ko": "-"
    }
}
    },"req_cx-logos-expect-1f978": {
        type: "REQUEST",
        name: "CX-Logos_Expectations.png",
path: "CX-Logos_Expectations.png",
pathFormatted: "req_cx-logos-expect-1f978",
stats: {
    "name": "CX-Logos_Expectations.png",
    "numberOfRequests": {
        "total": "9",
        "ok": "9",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "165",
        "ok": "165",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "668",
        "ok": "668",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "308",
        "ok": "308",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "140",
        "ok": "140",
        "ko": "-"
    },
    "percentiles1": {
        "total": "322",
        "ok": "322",
        "ko": "-"
    },
    "percentiles2": {
        "total": "343",
        "ok": "343",
        "ko": "-"
    },
    "percentiles3": {
        "total": "540",
        "ok": "540",
        "ko": "-"
    },
    "percentiles4": {
        "total": "642",
        "ok": "642",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 9,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.049",
        "ok": "0.049",
        "ko": "-"
    }
}
    },"req_values-be-bold--3a286": {
        type: "REQUEST",
        name: "Values-Be-Bold.png",
path: "Values-Be-Bold.png",
pathFormatted: "req_values-be-bold--3a286",
stats: {
    "name": "Values-Be-Bold.png",
    "numberOfRequests": {
        "total": "9",
        "ok": "9",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "165",
        "ok": "165",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1112",
        "ok": "1112",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "404",
        "ok": "404",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "280",
        "ok": "280",
        "ko": "-"
    },
    "percentiles1": {
        "total": "478",
        "ok": "478",
        "ko": "-"
    },
    "percentiles2": {
        "total": "548",
        "ok": "548",
        "ko": "-"
    },
    "percentiles3": {
        "total": "894",
        "ok": "894",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1068",
        "ok": "1068",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 9,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.049",
        "ok": "0.049",
        "ko": "-"
    }
}
    },"req_new--solutions--dcf9b": {
        type: "REQUEST",
        name: "NEW-_Solutions-Transformed-secure-infrastructure.png",
path: "NEW-_Solutions-Transformed-secure-infrastructure.png",
pathFormatted: "req_new--solutions--dcf9b",
stats: {
    "name": "NEW-_Solutions-Transformed-secure-infrastructure.png",
    "numberOfRequests": {
        "total": "9",
        "ok": "9",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "178",
        "ok": "178",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "459",
        "ok": "459",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "281",
        "ok": "281",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "82",
        "ok": "82",
        "ko": "-"
    },
    "percentiles1": {
        "total": "316",
        "ok": "316",
        "ko": "-"
    },
    "percentiles2": {
        "total": "327",
        "ok": "327",
        "ko": "-"
    },
    "percentiles3": {
        "total": "407",
        "ok": "407",
        "ko": "-"
    },
    "percentiles4": {
        "total": "449",
        "ok": "449",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 9,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.049",
        "ok": "0.049",
        "ko": "-"
    }
}
    },"req_cx-logos-resolu-f2096": {
        type: "REQUEST",
        name: "CX-Logos_Resolution.png",
path: "CX-Logos_Resolution.png",
pathFormatted: "req_cx-logos-resolu-f2096",
stats: {
    "name": "CX-Logos_Resolution.png",
    "numberOfRequests": {
        "total": "9",
        "ok": "9",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "174",
        "ok": "174",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "997",
        "ok": "997",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "419",
        "ok": "419",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "321",
        "ok": "321",
        "ko": "-"
    },
    "percentiles1": {
        "total": "499",
        "ok": "499",
        "ko": "-"
    },
    "percentiles2": {
        "total": "889",
        "ok": "889",
        "ko": "-"
    },
    "percentiles3": {
        "total": "993",
        "ok": "993",
        "ko": "-"
    },
    "percentiles4": {
        "total": "996",
        "ok": "996",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 9,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.049",
        "ok": "0.049",
        "ko": "-"
    }
}
    },"req_values-do-the-r-24231": {
        type: "REQUEST",
        name: "Values-Do-the-Right-Thing.png",
path: "Values-Do-the-Right-Thing.png",
pathFormatted: "req_values-do-the-r-24231",
stats: {
    "name": "Values-Do-the-Right-Thing.png",
    "numberOfRequests": {
        "total": "9",
        "ok": "9",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "175",
        "ok": "175",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1178",
        "ok": "1178",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "435",
        "ok": "435",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "301",
        "ok": "301",
        "ko": "-"
    },
    "percentiles1": {
        "total": "444",
        "ok": "444",
        "ko": "-"
    },
    "percentiles2": {
        "total": "634",
        "ok": "634",
        "ko": "-"
    },
    "percentiles3": {
        "total": "980",
        "ok": "980",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1138",
        "ok": "1138",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 9,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.049",
        "ok": "0.049",
        "ko": "-"
    }
}
    },"req_12-1-jpg-9af37": {
        type: "REQUEST",
        name: "12-1.jpg",
path: "12-1.jpg",
pathFormatted: "req_12-1-jpg-9af37",
stats: {
    "name": "12-1.jpg",
    "numberOfRequests": {
        "total": "9",
        "ok": "9",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "280",
        "ok": "280",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1731",
        "ok": "1731",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1087",
        "ok": "1087",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "460",
        "ok": "460",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1460",
        "ok": "1460",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1532",
        "ok": "1532",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1659",
        "ok": "1659",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1717",
        "ok": "1717",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 9,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.049",
        "ok": "0.049",
        "ko": "-"
    }
}
    },"req_rob-meehan-1-jp-c583e": {
        type: "REQUEST",
        name: "rob-meehan-1.jpg",
path: "rob-meehan-1.jpg",
pathFormatted: "req_rob-meehan-1-jp-c583e",
stats: {
    "name": "rob-meehan-1.jpg",
    "numberOfRequests": {
        "total": "9",
        "ok": "9",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "218",
        "ok": "218",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1558",
        "ok": "1558",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "872",
        "ok": "872",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "433",
        "ok": "433",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1019",
        "ok": "1019",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1430",
        "ok": "1430",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1548",
        "ok": "1548",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1556",
        "ok": "1556",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 9,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.049",
        "ok": "0.049",
        "ko": "-"
    }
}
    },"req_vedha-bharathi--1b34a": {
        type: "REQUEST",
        name: "vedha-bharathi-1.jpg",
path: "vedha-bharathi-1.jpg",
pathFormatted: "req_vedha-bharathi--1b34a",
stats: {
    "name": "vedha-bharathi-1.jpg",
    "numberOfRequests": {
        "total": "9",
        "ok": "9",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "562",
        "ok": "562",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1192",
        "ok": "1192",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "751",
        "ok": "751",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "172",
        "ok": "172",
        "ko": "-"
    },
    "percentiles1": {
        "total": "769",
        "ok": "769",
        "ko": "-"
    },
    "percentiles2": {
        "total": "811",
        "ok": "811",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1044",
        "ok": "1044",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1162",
        "ok": "1162",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 9,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.049",
        "ok": "0.049",
        "ko": "-"
    }
}
    },"req_bala-jagannatha-bf170": {
        type: "REQUEST",
        name: "bala-jagannathan.jpg",
path: "bala-jagannathan.jpg",
pathFormatted: "req_bala-jagannatha-bf170",
stats: {
    "name": "bala-jagannathan.jpg",
    "numberOfRequests": {
        "total": "9",
        "ok": "9",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "513",
        "ok": "513",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1413",
        "ok": "1413",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "971",
        "ok": "971",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "330",
        "ok": "330",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1314",
        "ok": "1314",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1349",
        "ok": "1349",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1391",
        "ok": "1391",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1409",
        "ok": "1409",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 9,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.049",
        "ok": "0.049",
        "ko": "-"
    }
}
    },"req_mike-wrought-jp-57ffa": {
        type: "REQUEST",
        name: "mike-wrought.jpg",
path: "mike-wrought.jpg",
pathFormatted: "req_mike-wrought-jp-57ffa",
stats: {
    "name": "mike-wrought.jpg",
    "numberOfRequests": {
        "total": "9",
        "ok": "9",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "253",
        "ok": "253",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1365",
        "ok": "1365",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "689",
        "ok": "689",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "316",
        "ok": "316",
        "ko": "-"
    },
    "percentiles1": {
        "total": "834",
        "ok": "834",
        "ko": "-"
    },
    "percentiles2": {
        "total": "956",
        "ok": "956",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1213",
        "ok": "1213",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1335",
        "ok": "1335",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 9,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.049",
        "ok": "0.049",
        "ko": "-"
    }
}
    },"req_jane-rudge-jpg-1ff4d": {
        type: "REQUEST",
        name: "jane-rudge.jpg",
path: "jane-rudge.jpg",
pathFormatted: "req_jane-rudge-jpg-1ff4d",
stats: {
    "name": "jane-rudge.jpg",
    "numberOfRequests": {
        "total": "9",
        "ok": "9",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "338",
        "ok": "338",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1604",
        "ok": "1604",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "821",
        "ok": "821",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "378",
        "ok": "378",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1131",
        "ok": "1131",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1160",
        "ok": "1160",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1429",
        "ok": "1429",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1569",
        "ok": "1569",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 9,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.049",
        "ok": "0.049",
        "ko": "-"
    }
}
    },"req_tony-leary-jpg-bca69": {
        type: "REQUEST",
        name: "tony-leary.jpg",
path: "tony-leary.jpg",
pathFormatted: "req_tony-leary-jpg-bca69",
stats: {
    "name": "tony-leary.jpg",
    "numberOfRequests": {
        "total": "9",
        "ok": "9",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "323",
        "ok": "323",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1231",
        "ok": "1231",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "638",
        "ok": "638",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "286",
        "ok": "286",
        "ko": "-"
    },
    "percentiles1": {
        "total": "796",
        "ok": "796",
        "ko": "-"
    },
    "percentiles2": {
        "total": "927",
        "ok": "927",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1123",
        "ok": "1123",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1209",
        "ok": "1209",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 9,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.049",
        "ok": "0.049",
        "ko": "-"
    }
}
    },"req_will-dorrington-ea595": {
        type: "REQUEST",
        name: "will-dorrington.jpg",
path: "will-dorrington.jpg",
pathFormatted: "req_will-dorrington-ea595",
stats: {
    "name": "will-dorrington.jpg",
    "numberOfRequests": {
        "total": "9",
        "ok": "9",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "267",
        "ok": "267",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "661",
        "ok": "661",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "424",
        "ok": "424",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "133",
        "ok": "133",
        "ko": "-"
    },
    "percentiles1": {
        "total": "521",
        "ok": "521",
        "ko": "-"
    },
    "percentiles2": {
        "total": "550",
        "ok": "550",
        "ko": "-"
    },
    "percentiles3": {
        "total": "619",
        "ok": "619",
        "ko": "-"
    },
    "percentiles4": {
        "total": "653",
        "ok": "653",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 9,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.049",
        "ok": "0.049",
        "ko": "-"
    }
}
    },"req_jon-paul-mcspor-2b336": {
        type: "REQUEST",
        name: "Jon-Paul-McSporran-scaled.jpg",
path: "Jon-Paul-McSporran-scaled.jpg",
pathFormatted: "req_jon-paul-mcspor-2b336",
stats: {
    "name": "Jon-Paul-McSporran-scaled.jpg",
    "numberOfRequests": {
        "total": "9",
        "ok": "9",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "323",
        "ok": "323",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "997",
        "ok": "997",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "615",
        "ok": "615",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "219",
        "ok": "219",
        "ko": "-"
    },
    "percentiles1": {
        "total": "685",
        "ok": "685",
        "ko": "-"
    },
    "percentiles2": {
        "total": "919",
        "ok": "919",
        "ko": "-"
    },
    "percentiles3": {
        "total": "989",
        "ok": "989",
        "ko": "-"
    },
    "percentiles4": {
        "total": "995",
        "ok": "995",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 9,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.049",
        "ok": "0.049",
        "ko": "-"
    }
}
    },"req_delivery-man-in-67e6a": {
        type: "REQUEST",
        name: "delivery-man-in-van-on-a-tablet.jpg",
path: "delivery-man-in-van-on-a-tablet.jpg",
pathFormatted: "req_delivery-man-in-67e6a",
stats: {
    "name": "delivery-man-in-van-on-a-tablet.jpg",
    "numberOfRequests": {
        "total": "9",
        "ok": "9",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "229",
        "ok": "229",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "664",
        "ok": "664",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "478",
        "ok": "478",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "125",
        "ok": "125",
        "ko": "-"
    },
    "percentiles1": {
        "total": "561",
        "ok": "561",
        "ko": "-"
    },
    "percentiles2": {
        "total": "570",
        "ok": "570",
        "ko": "-"
    },
    "percentiles3": {
        "total": "627",
        "ok": "627",
        "ko": "-"
    },
    "percentiles4": {
        "total": "657",
        "ok": "657",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 9,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.049",
        "ok": "0.049",
        "ko": "-"
    }
}
    },"req_two-man-sat-at--5ca40": {
        type: "REQUEST",
        name: "Two-man-sat-at-laptop-smilling-scaled.jpg",
path: "Two-man-sat-at-laptop-smilling-scaled.jpg",
pathFormatted: "req_two-man-sat-at--5ca40",
stats: {
    "name": "Two-man-sat-at-laptop-smilling-scaled.jpg",
    "numberOfRequests": {
        "total": "9",
        "ok": "9",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "426",
        "ok": "426",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1110",
        "ok": "1110",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "654",
        "ok": "654",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "220",
        "ok": "220",
        "ko": "-"
    },
    "percentiles1": {
        "total": "813",
        "ok": "813",
        "ko": "-"
    },
    "percentiles2": {
        "total": "823",
        "ok": "823",
        "ko": "-"
    },
    "percentiles3": {
        "total": "996",
        "ok": "996",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1087",
        "ok": "1087",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 9,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.049",
        "ok": "0.049",
        "ko": "-"
    }
}
    },"req_woman-raising-h-f8009": {
        type: "REQUEST",
        name: "woman-raising-hand-in-a-lecture.jpg",
path: "woman-raising-hand-in-a-lecture.jpg",
pathFormatted: "req_woman-raising-h-f8009",
stats: {
    "name": "woman-raising-hand-in-a-lecture.jpg",
    "numberOfRequests": {
        "total": "9",
        "ok": "9",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "222",
        "ok": "222",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "919",
        "ok": "919",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "528",
        "ok": "528",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "195",
        "ok": "195",
        "ko": "-"
    },
    "percentiles1": {
        "total": "606",
        "ok": "606",
        "ko": "-"
    },
    "percentiles2": {
        "total": "646",
        "ok": "646",
        "ko": "-"
    },
    "percentiles3": {
        "total": "814",
        "ok": "814",
        "ko": "-"
    },
    "percentiles4": {
        "total": "898",
        "ok": "898",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 9,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.049",
        "ok": "0.049",
        "ko": "-"
    }
}
    },"req_woman-smiling-w-17cf0": {
        type: "REQUEST",
        name: "woman-smiling-working-at-her-laptop-scaled.jpg",
path: "woman-smiling-working-at-her-laptop-scaled.jpg",
pathFormatted: "req_woman-smiling-w-17cf0",
stats: {
    "name": "woman-smiling-working-at-her-laptop-scaled.jpg",
    "numberOfRequests": {
        "total": "9",
        "ok": "9",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "274",
        "ok": "274",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "873",
        "ok": "873",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "612",
        "ok": "612",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "183",
        "ok": "183",
        "ko": "-"
    },
    "percentiles1": {
        "total": "725",
        "ok": "725",
        "ko": "-"
    },
    "percentiles2": {
        "total": "792",
        "ok": "792",
        "ko": "-"
    },
    "percentiles3": {
        "total": "847",
        "ok": "847",
        "ko": "-"
    },
    "percentiles4": {
        "total": "868",
        "ok": "868",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 9,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.049",
        "ok": "0.049",
        "ko": "-"
    }
}
    },"req_kerv-divisional-492d1": {
        type: "REQUEST",
        name: "Kerv_divisional-logo_Collaborate_Purple_RGB-e1649781358819-1024x415.png",
path: "Kerv_divisional-logo_Collaborate_Purple_RGB-e1649781358819-1024x415.png",
pathFormatted: "req_kerv-divisional-492d1",
stats: {
    "name": "Kerv_divisional-logo_Collaborate_Purple_RGB-e1649781358819-1024x415.png",
    "numberOfRequests": {
        "total": "9",
        "ok": "9",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "243",
        "ok": "243",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "756",
        "ok": "756",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "386",
        "ok": "386",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "171",
        "ok": "171",
        "ko": "-"
    },
    "percentiles1": {
        "total": "495",
        "ok": "495",
        "ko": "-"
    },
    "percentiles2": {
        "total": "555",
        "ok": "555",
        "ko": "-"
    },
    "percentiles3": {
        "total": "682",
        "ok": "682",
        "ko": "-"
    },
    "percentiles4": {
        "total": "741",
        "ok": "741",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 9,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.049",
        "ok": "0.049",
        "ko": "-"
    }
}
    },"req_kerv-divisional-5871f": {
        type: "REQUEST",
        name: "Kerv_divisional-logo_Transform_Purple_RGB-1-e1646133158416-1024x448.png",
path: "Kerv_divisional-logo_Transform_Purple_RGB-1-e1646133158416-1024x448.png",
pathFormatted: "req_kerv-divisional-5871f",
stats: {
    "name": "Kerv_divisional-logo_Transform_Purple_RGB-1-e1646133158416-1024x448.png",
    "numberOfRequests": {
        "total": "9",
        "ok": "9",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "215",
        "ok": "215",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "858",
        "ok": "858",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "334",
        "ok": "334",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "192",
        "ok": "192",
        "ko": "-"
    },
    "percentiles1": {
        "total": "331",
        "ok": "331",
        "ko": "-"
    },
    "percentiles2": {
        "total": "347",
        "ok": "347",
        "ko": "-"
    },
    "percentiles3": {
        "total": "655",
        "ok": "655",
        "ko": "-"
    },
    "percentiles4": {
        "total": "817",
        "ok": "817",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 9,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.049",
        "ok": "0.049",
        "ko": "-"
    }
}
    },"req_kerv-divisional-ca7e3": {
        type: "REQUEST",
        name: "Kerv_divisional-logo_Experience_Purple_RGB-1-e1648542554935-1024x423.png",
path: "Kerv_divisional-logo_Experience_Purple_RGB-1-e1648542554935-1024x423.png",
pathFormatted: "req_kerv-divisional-ca7e3",
stats: {
    "name": "Kerv_divisional-logo_Experience_Purple_RGB-1-e1648542554935-1024x423.png",
    "numberOfRequests": {
        "total": "9",
        "ok": "9",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "179",
        "ok": "179",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "741",
        "ok": "741",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "353",
        "ok": "353",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "174",
        "ok": "174",
        "ko": "-"
    },
    "percentiles1": {
        "total": "459",
        "ok": "459",
        "ko": "-"
    },
    "percentiles2": {
        "total": "469",
        "ok": "469",
        "ko": "-"
    },
    "percentiles3": {
        "total": "633",
        "ok": "633",
        "ko": "-"
    },
    "percentiles4": {
        "total": "719",
        "ok": "719",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 9,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.049",
        "ok": "0.049",
        "ko": "-"
    }
}
    },"req_kerv-divisional-cacdf": {
        type: "REQUEST",
        name: "Kerv_divisional-logo_Transform_Purple_RGB_Transform_Purple_RGB.png",
path: "Kerv_divisional-logo_Transform_Purple_RGB_Transform_Purple_RGB.png",
pathFormatted: "req_kerv-divisional-cacdf",
stats: {
    "name": "Kerv_divisional-logo_Transform_Purple_RGB_Transform_Purple_RGB.png",
    "numberOfRequests": {
        "total": "9",
        "ok": "9",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1797",
        "ok": "1797",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "4874",
        "ok": "4874",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "2647",
        "ok": "2647",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "940",
        "ok": "940",
        "ko": "-"
    },
    "percentiles1": {
        "total": "3078",
        "ok": "3078",
        "ko": "-"
    },
    "percentiles2": {
        "total": "3320",
        "ok": "3320",
        "ko": "-"
    },
    "percentiles3": {
        "total": "4277",
        "ok": "4277",
        "ko": "-"
    },
    "percentiles4": {
        "total": "4755",
        "ok": "4755",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 6,
    "percentage": 67
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 3,
    "percentage": 33
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.049",
        "ok": "0.049",
        "ko": "-"
    }
}
    },"req_footer-bg-e1649-19d2e": {
        type: "REQUEST",
        name: "footer-bg-e1649351827507.png",
path: "footer-bg-e1649351827507.png",
pathFormatted: "req_footer-bg-e1649-19d2e",
stats: {
    "name": "footer-bg-e1649351827507.png",
    "numberOfRequests": {
        "total": "13",
        "ok": "13",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "174",
        "ok": "174",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "933",
        "ok": "933",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "406",
        "ok": "406",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "243",
        "ok": "243",
        "ko": "-"
    },
    "percentiles1": {
        "total": "481",
        "ok": "481",
        "ko": "-"
    },
    "percentiles2": {
        "total": "708",
        "ok": "708",
        "ko": "-"
    },
    "percentiles3": {
        "total": "878",
        "ok": "878",
        "ko": "-"
    },
    "percentiles4": {
        "total": "922",
        "ok": "922",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 13,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.07",
        "ok": "0.07",
        "ko": "-"
    }
}
    },"req_kerv-reversed-s-8714c": {
        type: "REQUEST",
        name: "Kerv_Reversed_STRAP_RGB.png",
path: "Kerv_Reversed_STRAP_RGB.png",
pathFormatted: "req_kerv-reversed-s-8714c",
stats: {
    "name": "Kerv_Reversed_STRAP_RGB.png",
    "numberOfRequests": {
        "total": "13",
        "ok": "13",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "168",
        "ok": "168",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "900",
        "ok": "900",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "358",
        "ok": "358",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "249",
        "ok": "249",
        "ko": "-"
    },
    "percentiles1": {
        "total": "297",
        "ok": "297",
        "ko": "-"
    },
    "percentiles2": {
        "total": "707",
        "ok": "707",
        "ko": "-"
    },
    "percentiles3": {
        "total": "855",
        "ok": "855",
        "ko": "-"
    },
    "percentiles4": {
        "total": "891",
        "ok": "891",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 13,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.07",
        "ok": "0.07",
        "ko": "-"
    }
}
    },"req_linkedin-png-fdff0": {
        type: "REQUEST",
        name: "linkedin.png",
path: "linkedin.png",
pathFormatted: "req_linkedin-png-fdff0",
stats: {
    "name": "linkedin.png",
    "numberOfRequests": {
        "total": "13",
        "ok": "13",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "162",
        "ok": "162",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "766",
        "ok": "766",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "313",
        "ok": "313",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "183",
        "ok": "183",
        "ko": "-"
    },
    "percentiles1": {
        "total": "283",
        "ok": "283",
        "ko": "-"
    },
    "percentiles2": {
        "total": "446",
        "ok": "446",
        "ko": "-"
    },
    "percentiles3": {
        "total": "709",
        "ok": "709",
        "ko": "-"
    },
    "percentiles4": {
        "total": "755",
        "ok": "755",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 13,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.07",
        "ok": "0.07",
        "ko": "-"
    }
}
    },"req_twitter-png-10e35": {
        type: "REQUEST",
        name: "twitter.png",
path: "twitter.png",
pathFormatted: "req_twitter-png-10e35",
stats: {
    "name": "twitter.png",
    "numberOfRequests": {
        "total": "13",
        "ok": "13",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "170",
        "ok": "170",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1150",
        "ok": "1150",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "336",
        "ok": "336",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "274",
        "ok": "274",
        "ko": "-"
    },
    "percentiles1": {
        "total": "271",
        "ok": "271",
        "ko": "-"
    },
    "percentiles2": {
        "total": "385",
        "ok": "385",
        "ko": "-"
    },
    "percentiles3": {
        "total": "903",
        "ok": "903",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1101",
        "ok": "1101",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 13,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.07",
        "ok": "0.07",
        "ko": "-"
    }
}
    },"req_regenerator-run-4c6cd": {
        type: "REQUEST",
        name: "regenerator-runtime.min.js?ver=0.13.9",
path: "regenerator-runtime.min.js?ver=0.13.9",
pathFormatted: "req_regenerator-run-4c6cd",
stats: {
    "name": "regenerator-runtime.min.js?ver=0.13.9",
    "numberOfRequests": {
        "total": "9",
        "ok": "9",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "177",
        "ok": "177",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1007",
        "ok": "1007",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "471",
        "ok": "471",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "290",
        "ok": "290",
        "ko": "-"
    },
    "percentiles1": {
        "total": "726",
        "ok": "726",
        "ko": "-"
    },
    "percentiles2": {
        "total": "792",
        "ok": "792",
        "ko": "-"
    },
    "percentiles3": {
        "total": "927",
        "ok": "927",
        "ko": "-"
    },
    "percentiles4": {
        "total": "991",
        "ok": "991",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 9,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.049",
        "ok": "0.049",
        "ko": "-"
    }
}
    },"req_wp-polyfill-min-59798": {
        type: "REQUEST",
        name: "wp-polyfill.min.js?ver=3.15.0",
path: "wp-polyfill.min.js?ver=3.15.0",
pathFormatted: "req_wp-polyfill-min-59798",
stats: {
    "name": "wp-polyfill.min.js?ver=3.15.0",
    "numberOfRequests": {
        "total": "9",
        "ok": "9",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "191",
        "ok": "191",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "721",
        "ok": "721",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "425",
        "ok": "425",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "214",
        "ok": "214",
        "ko": "-"
    },
    "percentiles1": {
        "total": "685",
        "ok": "685",
        "ko": "-"
    },
    "percentiles2": {
        "total": "687",
        "ok": "687",
        "ko": "-"
    },
    "percentiles3": {
        "total": "708",
        "ok": "708",
        "ko": "-"
    },
    "percentiles4": {
        "total": "718",
        "ok": "718",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 9,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.049",
        "ok": "0.049",
        "ko": "-"
    }
}
    },"req_dom-ready-min-j-f6551": {
        type: "REQUEST",
        name: "dom-ready.min.js?ver=ecda74de0221e1c2ce5c57cbb5af09d5",
path: "dom-ready.min.js?ver=ecda74de0221e1c2ce5c57cbb5af09d5",
pathFormatted: "req_dom-ready-min-j-f6551",
stats: {
    "name": "dom-ready.min.js?ver=ecda74de0221e1c2ce5c57cbb5af09d5",
    "numberOfRequests": {
        "total": "9",
        "ok": "9",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "190",
        "ok": "190",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "951",
        "ok": "951",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "469",
        "ok": "469",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "273",
        "ok": "273",
        "ko": "-"
    },
    "percentiles1": {
        "total": "693",
        "ok": "693",
        "ko": "-"
    },
    "percentiles2": {
        "total": "714",
        "ok": "714",
        "ko": "-"
    },
    "percentiles3": {
        "total": "858",
        "ok": "858",
        "ko": "-"
    },
    "percentiles4": {
        "total": "932",
        "ok": "932",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 9,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.049",
        "ok": "0.049",
        "ko": "-"
    }
}
    },"req_hooks-min-js-ve-71377": {
        type: "REQUEST",
        name: "hooks.min.js?ver=1e58c8c5a32b2e97491080c5b10dc71c",
path: "hooks.min.js?ver=1e58c8c5a32b2e97491080c5b10dc71c",
pathFormatted: "req_hooks-min-js-ve-71377",
stats: {
    "name": "hooks.min.js?ver=1e58c8c5a32b2e97491080c5b10dc71c",
    "numberOfRequests": {
        "total": "9",
        "ok": "9",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "194",
        "ok": "194",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "953",
        "ok": "953",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "483",
        "ok": "483",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "247",
        "ok": "247",
        "ko": "-"
    },
    "percentiles1": {
        "total": "669",
        "ok": "669",
        "ko": "-"
    },
    "percentiles2": {
        "total": "679",
        "ok": "679",
        "ko": "-"
    },
    "percentiles3": {
        "total": "845",
        "ok": "845",
        "ko": "-"
    },
    "percentiles4": {
        "total": "931",
        "ok": "931",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 9,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.049",
        "ok": "0.049",
        "ko": "-"
    }
}
    },"req_i18n-min-js-ver-b650d": {
        type: "REQUEST",
        name: "i18n.min.js?ver=30fcecb428a0e8383d3776bcdd3a7834",
path: "i18n.min.js?ver=30fcecb428a0e8383d3776bcdd3a7834",
pathFormatted: "req_i18n-min-js-ver-b650d",
stats: {
    "name": "i18n.min.js?ver=30fcecb428a0e8383d3776bcdd3a7834",
    "numberOfRequests": {
        "total": "9",
        "ok": "9",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "218",
        "ok": "218",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "672",
        "ok": "672",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "470",
        "ok": "470",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "158",
        "ok": "158",
        "ko": "-"
    },
    "percentiles1": {
        "total": "594",
        "ok": "594",
        "ko": "-"
    },
    "percentiles2": {
        "total": "652",
        "ok": "652",
        "ko": "-"
    },
    "percentiles3": {
        "total": "670",
        "ok": "670",
        "ko": "-"
    },
    "percentiles4": {
        "total": "672",
        "ok": "672",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 9,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.049",
        "ok": "0.049",
        "ko": "-"
    }
}
    },"req_a11y-min-js-ver-673af": {
        type: "REQUEST",
        name: "a11y.min.js?ver=68e470cf840f69530e9db3be229ad4b6",
path: "a11y.min.js?ver=68e470cf840f69530e9db3be229ad4b6",
pathFormatted: "req_a11y-min-js-ver-673af",
stats: {
    "name": "a11y.min.js?ver=68e470cf840f69530e9db3be229ad4b6",
    "numberOfRequests": {
        "total": "9",
        "ok": "9",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "207",
        "ok": "207",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1099",
        "ok": "1099",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "585",
        "ok": "585",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "286",
        "ok": "286",
        "ko": "-"
    },
    "percentiles1": {
        "total": "736",
        "ok": "736",
        "ko": "-"
    },
    "percentiles2": {
        "total": "830",
        "ok": "830",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1001",
        "ok": "1001",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1079",
        "ok": "1079",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 9,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.049",
        "ok": "0.049",
        "ko": "-"
    }
}
    },"req_jquery-min-js-v-1252b": {
        type: "REQUEST",
        name: "jquery.min.js?ver=3.6.0",
path: "jquery.min.js?ver=3.6.0",
pathFormatted: "req_jquery-min-js-v-1252b",
stats: {
    "name": "jquery.min.js?ver=3.6.0",
    "numberOfRequests": {
        "total": "13",
        "ok": "13",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "303",
        "ok": "303",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1184",
        "ok": "1184",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "566",
        "ok": "566",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "287",
        "ok": "287",
        "ko": "-"
    },
    "percentiles1": {
        "total": "607",
        "ok": "607",
        "ko": "-"
    },
    "percentiles2": {
        "total": "863",
        "ok": "863",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1160",
        "ok": "1160",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1179",
        "ok": "1179",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 13,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.07",
        "ok": "0.07",
        "ko": "-"
    }
}
    },"req_jquery-migrate--79e4d": {
        type: "REQUEST",
        name: "jquery-migrate.min.js?ver=3.3.2",
path: "jquery-migrate.min.js?ver=3.3.2",
pathFormatted: "req_jquery-migrate--79e4d",
stats: {
    "name": "jquery-migrate.min.js?ver=3.3.2",
    "numberOfRequests": {
        "total": "9",
        "ok": "9",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "196",
        "ok": "196",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1184",
        "ok": "1184",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "569",
        "ok": "569",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "303",
        "ok": "303",
        "ko": "-"
    },
    "percentiles1": {
        "total": "792",
        "ok": "792",
        "ko": "-"
    },
    "percentiles2": {
        "total": "797",
        "ok": "797",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1030",
        "ok": "1030",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1153",
        "ok": "1153",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 9,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.049",
        "ok": "0.049",
        "ko": "-"
    }
}
    },"req_jquery-json-min-ff39f": {
        type: "REQUEST",
        name: "jquery.json.min.js?ver=2.5.15.2",
path: "jquery.json.min.js?ver=2.5.15.2",
pathFormatted: "req_jquery-json-min-ff39f",
stats: {
    "name": "jquery.json.min.js?ver=2.5.15.2",
    "numberOfRequests": {
        "total": "9",
        "ok": "9",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "211",
        "ok": "211",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1184",
        "ok": "1184",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "556",
        "ok": "556",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "339",
        "ok": "339",
        "ko": "-"
    },
    "percentiles1": {
        "total": "799",
        "ok": "799",
        "ko": "-"
    },
    "percentiles2": {
        "total": "948",
        "ok": "948",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1104",
        "ok": "1104",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1168",
        "ok": "1168",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 9,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.049",
        "ok": "0.049",
        "ko": "-"
    }
}
    },"req_gravityforms-mi-68f64": {
        type: "REQUEST",
        name: "gravityforms.min.js?ver=2.5.15.2",
path: "gravityforms.min.js?ver=2.5.15.2",
pathFormatted: "req_gravityforms-mi-68f64",
stats: {
    "name": "gravityforms.min.js?ver=2.5.15.2",
    "numberOfRequests": {
        "total": "9",
        "ok": "9",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "240",
        "ok": "240",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1192",
        "ok": "1192",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "607",
        "ok": "607",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "323",
        "ok": "323",
        "ko": "-"
    },
    "percentiles1": {
        "total": "809",
        "ok": "809",
        "ko": "-"
    },
    "percentiles2": {
        "total": "954",
        "ok": "954",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1111",
        "ok": "1111",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1176",
        "ok": "1176",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 9,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.049",
        "ok": "0.049",
        "ko": "-"
    }
}
    },"req_borlabs-cookie--8ee71": {
        type: "REQUEST",
        name: "borlabs-cookie.min.js?ver=2.2.49",
path: "borlabs-cookie.min.js?ver=2.2.49",
pathFormatted: "req_borlabs-cookie--8ee71",
stats: {
    "name": "borlabs-cookie.min.js?ver=2.2.49",
    "numberOfRequests": {
        "total": "13",
        "ok": "13",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "161",
        "ok": "161",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "944",
        "ok": "944",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "376",
        "ok": "376",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "233",
        "ok": "233",
        "ko": "-"
    },
    "percentiles1": {
        "total": "382",
        "ok": "382",
        "ko": "-"
    },
    "percentiles2": {
        "total": "677",
        "ok": "677",
        "ko": "-"
    },
    "percentiles3": {
        "total": "791",
        "ok": "791",
        "ko": "-"
    },
    "percentiles4": {
        "total": "913",
        "ok": "913",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 13,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.07",
        "ok": "0.07",
        "ko": "-"
    }
}
    },"req_request-29-6a22e": {
        type: "REQUEST",
        name: "request_29",
path: "request_29",
pathFormatted: "req_request-29-6a22e",
stats: {
    "name": "request_29",
    "numberOfRequests": {
        "total": "8",
        "ok": "8",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1431",
        "ok": "1431",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "4196",
        "ok": "4196",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "2955",
        "ok": "2955",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "906",
        "ok": "906",
        "ko": "-"
    },
    "percentiles1": {
        "total": "3706",
        "ok": "3706",
        "ko": "-"
    },
    "percentiles2": {
        "total": "3741",
        "ok": "3741",
        "ko": "-"
    },
    "percentiles3": {
        "total": "4037",
        "ok": "4037",
        "ko": "-"
    },
    "percentiles4": {
        "total": "4164",
        "ok": "4164",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 3,
    "percentage": 38
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 5,
    "percentage": 63
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.043",
        "ok": "0.043",
        "ko": "-"
    }
}
    },"req_request-41-12d9b": {
        type: "REQUEST",
        name: "request_41",
path: "request_41",
pathFormatted: "req_request-41-12d9b",
stats: {
    "name": "request_41",
    "numberOfRequests": {
        "total": "2",
        "ok": "2",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "912",
        "ok": "912",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1193",
        "ok": "1193",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1053",
        "ok": "1053",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "141",
        "ok": "141",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1123",
        "ok": "1123",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1151",
        "ok": "1151",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1179",
        "ok": "1179",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1190",
        "ok": "1190",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 2,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.011",
        "ok": "0.011",
        "ko": "-"
    }
}
    },"req_request-43-a95c1": {
        type: "REQUEST",
        name: "request_43",
path: "request_43",
pathFormatted: "req_request-43-a95c1",
stats: {
    "name": "request_43",
    "numberOfRequests": {
        "total": "7",
        "ok": "7",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "275",
        "ok": "275",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1210",
        "ok": "1210",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "535",
        "ok": "535",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "346",
        "ok": "346",
        "ko": "-"
    },
    "percentiles1": {
        "total": "664",
        "ok": "664",
        "ko": "-"
    },
    "percentiles2": {
        "total": "948",
        "ok": "948",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1123",
        "ok": "1123",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1193",
        "ok": "1193",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 7,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.038",
        "ok": "0.038",
        "ko": "-"
    }
}
    },"req_request-44-7d234": {
        type: "REQUEST",
        name: "request_44",
path: "request_44",
pathFormatted: "req_request-44-7d234",
stats: {
    "name": "request_44",
    "numberOfRequests": {
        "total": "7",
        "ok": "7",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "171",
        "ok": "171",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "742",
        "ok": "742",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "373",
        "ok": "373",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "166",
        "ok": "166",
        "ko": "-"
    },
    "percentiles1": {
        "total": "396",
        "ok": "396",
        "ko": "-"
    },
    "percentiles2": {
        "total": "434",
        "ok": "434",
        "ko": "-"
    },
    "percentiles3": {
        "total": "639",
        "ok": "639",
        "ko": "-"
    },
    "percentiles4": {
        "total": "721",
        "ok": "721",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 7,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.038",
        "ok": "0.038",
        "ko": "-"
    }
}
    },"req_request-53-369eb": {
        type: "REQUEST",
        name: "request_53",
path: "request_53",
pathFormatted: "req_request-53-369eb",
stats: {
    "name": "request_53",
    "numberOfRequests": {
        "total": "9",
        "ok": "9",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "178",
        "ok": "178",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "920",
        "ok": "920",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "505",
        "ok": "505",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "313",
        "ok": "313",
        "ko": "-"
    },
    "percentiles1": {
        "total": "827",
        "ok": "827",
        "ko": "-"
    },
    "percentiles2": {
        "total": "879",
        "ok": "879",
        "ko": "-"
    },
    "percentiles3": {
        "total": "909",
        "ok": "909",
        "ko": "-"
    },
    "percentiles4": {
        "total": "918",
        "ok": "918",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 9,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.049",
        "ok": "0.049",
        "ko": "-"
    }
}
    },"req_request-42-f6be0": {
        type: "REQUEST",
        name: "request_42",
path: "request_42",
pathFormatted: "req_request-42-f6be0",
stats: {
    "name": "request_42",
    "numberOfRequests": {
        "total": "6",
        "ok": "6",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "169",
        "ok": "169",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "910",
        "ok": "910",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "448",
        "ok": "448",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "295",
        "ok": "295",
        "ko": "-"
    },
    "percentiles1": {
        "total": "684",
        "ok": "684",
        "ko": "-"
    },
    "percentiles2": {
        "total": "834",
        "ok": "834",
        "ko": "-"
    },
    "percentiles3": {
        "total": "885",
        "ok": "885",
        "ko": "-"
    },
    "percentiles4": {
        "total": "905",
        "ok": "905",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 6,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.032",
        "ok": "0.032",
        "ko": "-"
    }
}
    },"req_request-54-22e8b": {
        type: "REQUEST",
        name: "request_54",
path: "request_54",
pathFormatted: "req_request-54-22e8b",
stats: {
    "name": "request_54",
    "numberOfRequests": {
        "total": "9",
        "ok": "9",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "184",
        "ok": "184",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1312",
        "ok": "1312",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "499",
        "ok": "499",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "353",
        "ok": "353",
        "ko": "-"
    },
    "percentiles1": {
        "total": "494",
        "ok": "494",
        "ko": "-"
    },
    "percentiles2": {
        "total": "818",
        "ok": "818",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1147",
        "ok": "1147",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1279",
        "ok": "1279",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 9,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.049",
        "ok": "0.049",
        "ko": "-"
    }
}
    },"req_request-55-784ce": {
        type: "REQUEST",
        name: "request_55",
path: "request_55",
pathFormatted: "req_request-55-784ce",
stats: {
    "name": "request_55",
    "numberOfRequests": {
        "total": "9",
        "ok": "9",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "205",
        "ok": "205",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1579",
        "ok": "1579",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "757",
        "ok": "757",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "514",
        "ok": "514",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1369",
        "ok": "1369",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1428",
        "ok": "1428",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1525",
        "ok": "1525",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1568",
        "ok": "1568",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 9,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.049",
        "ok": "0.049",
        "ko": "-"
    }
}
    },"req_request-56-ffd25": {
        type: "REQUEST",
        name: "request_56",
path: "request_56",
pathFormatted: "req_request-56-ffd25",
stats: {
    "name": "request_56",
    "numberOfRequests": {
        "total": "9",
        "ok": "9",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "165",
        "ok": "165",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1534",
        "ok": "1534",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "573",
        "ok": "573",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "463",
        "ok": "463",
        "ko": "-"
    },
    "percentiles1": {
        "total": "635",
        "ok": "635",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1092",
        "ok": "1092",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1403",
        "ok": "1403",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1508",
        "ok": "1508",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 9,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.049",
        "ok": "0.049",
        "ko": "-"
    }
}
    },"req_request-57-c84ef": {
        type: "REQUEST",
        name: "request_57",
path: "request_57",
pathFormatted: "req_request-57-c84ef",
stats: {
    "name": "request_57",
    "numberOfRequests": {
        "total": "9",
        "ok": "9",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "158",
        "ok": "158",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1512",
        "ok": "1512",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "538",
        "ok": "538",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "472",
        "ok": "472",
        "ko": "-"
    },
    "percentiles1": {
        "total": "624",
        "ok": "624",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1075",
        "ok": "1075",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1382",
        "ok": "1382",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1486",
        "ok": "1486",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 9,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.049",
        "ok": "0.049",
        "ko": "-"
    }
}
    },"req_request-58-a56e4": {
        type: "REQUEST",
        name: "request_58",
path: "request_58",
pathFormatted: "req_request-58-a56e4",
stats: {
    "name": "request_58",
    "numberOfRequests": {
        "total": "9",
        "ok": "9",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "180",
        "ok": "180",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1818",
        "ok": "1818",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "568",
        "ok": "568",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "465",
        "ok": "465",
        "ko": "-"
    },
    "percentiles1": {
        "total": "641",
        "ok": "641",
        "ko": "-"
    },
    "percentiles2": {
        "total": "647",
        "ok": "647",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1350",
        "ok": "1350",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1724",
        "ok": "1724",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 9,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.049",
        "ok": "0.049",
        "ko": "-"
    }
}
    },"req_request-59-9384e": {
        type: "REQUEST",
        name: "request_59",
path: "request_59",
pathFormatted: "req_request-59-9384e",
stats: {
    "name": "request_59",
    "numberOfRequests": {
        "total": "9",
        "ok": "9",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "160",
        "ok": "160",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "890",
        "ok": "890",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "430",
        "ok": "430",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "292",
        "ok": "292",
        "ko": "-"
    },
    "percentiles1": {
        "total": "756",
        "ok": "756",
        "ko": "-"
    },
    "percentiles2": {
        "total": "844",
        "ok": "844",
        "ko": "-"
    },
    "percentiles3": {
        "total": "880",
        "ok": "880",
        "ko": "-"
    },
    "percentiles4": {
        "total": "888",
        "ok": "888",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 9,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.049",
        "ok": "0.049",
        "ko": "-"
    }
}
    },"req_request-74-7654e": {
        type: "REQUEST",
        name: "request_74",
path: "request_74",
pathFormatted: "req_request-74-7654e",
stats: {
    "name": "request_74",
    "numberOfRequests": {
        "total": "10",
        "ok": "10",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "127",
        "ok": "127",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "408",
        "ok": "408",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "208",
        "ok": "208",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "91",
        "ok": "91",
        "ko": "-"
    },
    "percentiles1": {
        "total": "277",
        "ok": "277",
        "ko": "-"
    },
    "percentiles2": {
        "total": "287",
        "ok": "287",
        "ko": "-"
    },
    "percentiles3": {
        "total": "354",
        "ok": "354",
        "ko": "-"
    },
    "percentiles4": {
        "total": "397",
        "ok": "397",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 10,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.054",
        "ok": "0.054",
        "ko": "-"
    }
}
    },"req_request-75-91c13": {
        type: "REQUEST",
        name: "request_75",
path: "request_75",
pathFormatted: "req_request-75-91c13",
stats: {
    "name": "request_75",
    "numberOfRequests": {
        "total": "10",
        "ok": "10",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "95",
        "ok": "95",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "576",
        "ok": "576",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "200",
        "ok": "200",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "146",
        "ok": "146",
        "ko": "-"
    },
    "percentiles1": {
        "total": "242",
        "ok": "242",
        "ko": "-"
    },
    "percentiles2": {
        "total": "302",
        "ok": "302",
        "ko": "-"
    },
    "percentiles3": {
        "total": "463",
        "ok": "463",
        "ko": "-"
    },
    "percentiles4": {
        "total": "554",
        "ok": "554",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 10,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.054",
        "ok": "0.054",
        "ko": "-"
    }
}
    },"req_request-76-9f169": {
        type: "REQUEST",
        name: "request_76",
path: "request_76",
pathFormatted: "req_request-76-9f169",
stats: {
    "name": "request_76",
    "numberOfRequests": {
        "total": "10",
        "ok": "10",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "145",
        "ok": "145",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "883",
        "ok": "883",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "347",
        "ok": "347",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "261",
        "ok": "261",
        "ko": "-"
    },
    "percentiles1": {
        "total": "319",
        "ok": "319",
        "ko": "-"
    },
    "percentiles2": {
        "total": "659",
        "ok": "659",
        "ko": "-"
    },
    "percentiles3": {
        "total": "861",
        "ok": "861",
        "ko": "-"
    },
    "percentiles4": {
        "total": "879",
        "ok": "879",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 10,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.054",
        "ok": "0.054",
        "ko": "-"
    }
}
    },"req_request-77-0fd09": {
        type: "REQUEST",
        name: "request_77",
path: "request_77",
pathFormatted: "req_request-77-0fd09",
stats: {
    "name": "request_77",
    "numberOfRequests": {
        "total": "10",
        "ok": "10",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "162",
        "ok": "162",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1170",
        "ok": "1170",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "435",
        "ok": "435",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "354",
        "ok": "354",
        "ko": "-"
    },
    "percentiles1": {
        "total": "431",
        "ok": "431",
        "ko": "-"
    },
    "percentiles2": {
        "total": "863",
        "ok": "863",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1127",
        "ok": "1127",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1161",
        "ok": "1161",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 10,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.054",
        "ok": "0.054",
        "ko": "-"
    }
}
    },"req_request-78-a111b": {
        type: "REQUEST",
        name: "request_78",
path: "request_78",
pathFormatted: "req_request-78-a111b",
stats: {
    "name": "request_78",
    "numberOfRequests": {
        "total": "10",
        "ok": "10",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "138",
        "ok": "138",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "598",
        "ok": "598",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "285",
        "ok": "285",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "150",
        "ok": "150",
        "ko": "-"
    },
    "percentiles1": {
        "total": "304",
        "ok": "304",
        "ko": "-"
    },
    "percentiles2": {
        "total": "458",
        "ok": "458",
        "ko": "-"
    },
    "percentiles3": {
        "total": "568",
        "ok": "568",
        "ko": "-"
    },
    "percentiles4": {
        "total": "592",
        "ok": "592",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 10,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.054",
        "ok": "0.054",
        "ko": "-"
    }
}
    },"req_request-79-a964b": {
        type: "REQUEST",
        name: "request_79",
path: "request_79",
pathFormatted: "req_request-79-a964b",
stats: {
    "name": "request_79",
    "numberOfRequests": {
        "total": "10",
        "ok": "10",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "127",
        "ok": "127",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "602",
        "ok": "602",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "293",
        "ok": "293",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "148",
        "ok": "148",
        "ko": "-"
    },
    "percentiles1": {
        "total": "363",
        "ok": "363",
        "ko": "-"
    },
    "percentiles2": {
        "total": "462",
        "ok": "462",
        "ko": "-"
    },
    "percentiles3": {
        "total": "555",
        "ok": "555",
        "ko": "-"
    },
    "percentiles4": {
        "total": "593",
        "ok": "593",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 10,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.054",
        "ok": "0.054",
        "ko": "-"
    }
}
    },"req_request-40-3bad7": {
        type: "REQUEST",
        name: "request_40",
path: "request_40",
pathFormatted: "req_request-40-3bad7",
stats: {
    "name": "request_40",
    "numberOfRequests": {
        "total": "3",
        "ok": "3",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "380",
        "ok": "380",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1044",
        "ok": "1044",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "640",
        "ok": "640",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "290",
        "ok": "290",
        "ko": "-"
    },
    "percentiles1": {
        "total": "770",
        "ok": "770",
        "ko": "-"
    },
    "percentiles2": {
        "total": "880",
        "ok": "880",
        "ko": "-"
    },
    "percentiles3": {
        "total": "989",
        "ok": "989",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1033",
        "ok": "1033",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 3,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.016",
        "ok": "0.016",
        "ko": "-"
    }
}
    },"req_request-80-70dc2": {
        type: "REQUEST",
        name: "request_80",
path: "request_80",
pathFormatted: "req_request-80-70dc2",
stats: {
    "name": "request_80",
    "numberOfRequests": {
        "total": "10",
        "ok": "10",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "46",
        "ok": "46",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "328",
        "ok": "328",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "132",
        "ok": "132",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "102",
        "ok": "102",
        "ko": "-"
    },
    "percentiles1": {
        "total": "152",
        "ok": "152",
        "ko": "-"
    },
    "percentiles2": {
        "total": "268",
        "ok": "268",
        "ko": "-"
    },
    "percentiles3": {
        "total": "325",
        "ok": "325",
        "ko": "-"
    },
    "percentiles4": {
        "total": "327",
        "ok": "327",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 10,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.054",
        "ok": "0.054",
        "ko": "-"
    }
}
    },"req_request-81-6b89b": {
        type: "REQUEST",
        name: "request_81",
path: "request_81",
pathFormatted: "req_request-81-6b89b",
stats: {
    "name": "request_81",
    "numberOfRequests": {
        "total": "10",
        "ok": "10",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "61",
        "ok": "61",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "446",
        "ok": "446",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "127",
        "ok": "127",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "117",
        "ok": "117",
        "ko": "-"
    },
    "percentiles1": {
        "total": "83",
        "ok": "83",
        "ko": "-"
    },
    "percentiles2": {
        "total": "184",
        "ok": "184",
        "ko": "-"
    },
    "percentiles3": {
        "total": "352",
        "ok": "352",
        "ko": "-"
    },
    "percentiles4": {
        "total": "427",
        "ok": "427",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 10,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.054",
        "ok": "0.054",
        "ko": "-"
    }
}
    },"req_request-82-b5013": {
        type: "REQUEST",
        name: "request_82",
path: "request_82",
pathFormatted: "req_request-82-b5013",
stats: {
    "name": "request_82",
    "numberOfRequests": {
        "total": "10",
        "ok": "10",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "9279",
        "ok": "9279",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "13686",
        "ok": "13686",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "11632",
        "ok": "11632",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "1600",
        "ok": "1600",
        "ko": "-"
    },
    "percentiles1": {
        "total": "12868",
        "ok": "12868",
        "ko": "-"
    },
    "percentiles2": {
        "total": "13327",
        "ok": "13327",
        "ko": "-"
    },
    "percentiles3": {
        "total": "13601",
        "ok": "13601",
        "ko": "-"
    },
    "percentiles4": {
        "total": "13669",
        "ok": "13669",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 10,
    "percentage": 100
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.054",
        "ok": "0.054",
        "ko": "-"
    }
}
    },"req_request-102-37bf8": {
        type: "REQUEST",
        name: "request_102",
path: "request_102",
pathFormatted: "req_request-102-37bf8",
stats: {
    "name": "request_102",
    "numberOfRequests": {
        "total": "10",
        "ok": "9",
        "ko": "1"
    },
    "minResponseTime": {
        "total": "146",
        "ok": "146",
        "ko": "60011"
    },
    "maxResponseTime": {
        "total": "60011",
        "ok": "978",
        "ko": "60011"
    },
    "meanResponseTime": {
        "total": "6308",
        "ok": "341",
        "ko": "60011"
    },
    "standardDeviation": {
        "total": "17903",
        "ok": "258",
        "ko": "0"
    },
    "percentiles1": {
        "total": "518",
        "ok": "315",
        "ko": "60011"
    },
    "percentiles2": {
        "total": "840",
        "ok": "531",
        "ko": "60011"
    },
    "percentiles3": {
        "total": "33446",
        "ok": "821",
        "ko": "60011"
    },
    "percentiles4": {
        "total": "54698",
        "ok": "947",
        "ko": "60011"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 9,
    "percentage": 90
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 1,
    "percentage": 10
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.054",
        "ok": "0.049",
        "ko": "0.005"
    }
}
    },"req_request-96-b8b8c": {
        type: "REQUEST",
        name: "request_96",
path: "request_96",
pathFormatted: "req_request-96-b8b8c",
stats: {
    "name": "request_96",
    "numberOfRequests": {
        "total": "10",
        "ok": "10",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "263",
        "ok": "263",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1716",
        "ok": "1716",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "802",
        "ok": "802",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "487",
        "ok": "487",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1087",
        "ok": "1087",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1337",
        "ok": "1337",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1602",
        "ok": "1602",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1693",
        "ok": "1693",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 10,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.054",
        "ok": "0.054",
        "ko": "-"
    }
}
    },"req_request-100-4cc51": {
        type: "REQUEST",
        name: "request_100",
path: "request_100",
pathFormatted: "req_request-100-4cc51",
stats: {
    "name": "request_100",
    "numberOfRequests": {
        "total": "7",
        "ok": "7",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "144",
        "ok": "144",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "964",
        "ok": "964",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "394",
        "ok": "394",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "299",
        "ok": "299",
        "ko": "-"
    },
    "percentiles1": {
        "total": "501",
        "ok": "501",
        "ko": "-"
    },
    "percentiles2": {
        "total": "764",
        "ok": "764",
        "ko": "-"
    },
    "percentiles3": {
        "total": "897",
        "ok": "897",
        "ko": "-"
    },
    "percentiles4": {
        "total": "951",
        "ok": "951",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 7,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.038",
        "ok": "0.038",
        "ko": "-"
    }
}
    },"req_request-109-a9b0b": {
        type: "REQUEST",
        name: "request_109",
path: "request_109",
pathFormatted: "req_request-109-a9b0b",
stats: {
    "name": "request_109",
    "numberOfRequests": {
        "total": "10",
        "ok": "10",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1669",
        "ok": "1669",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "2926",
        "ok": "2926",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "2040",
        "ok": "2040",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "364",
        "ok": "364",
        "ko": "-"
    },
    "percentiles1": {
        "total": "2152",
        "ok": "2152",
        "ko": "-"
    },
    "percentiles2": {
        "total": "2322",
        "ok": "2322",
        "ko": "-"
    },
    "percentiles3": {
        "total": "2691",
        "ok": "2691",
        "ko": "-"
    },
    "percentiles4": {
        "total": "2879",
        "ok": "2879",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 10,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.054",
        "ok": "0.054",
        "ko": "-"
    }
}
    },"req_request-92-c5d15": {
        type: "REQUEST",
        name: "request_92",
path: "request_92",
pathFormatted: "req_request-92-c5d15",
stats: {
    "name": "request_92",
    "numberOfRequests": {
        "total": "10",
        "ok": "10",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "109",
        "ok": "109",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1535",
        "ok": "1535",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "453",
        "ok": "453",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "488",
        "ok": "488",
        "ko": "-"
    },
    "percentiles1": {
        "total": "521",
        "ok": "521",
        "ko": "-"
    },
    "percentiles2": {
        "total": "964",
        "ok": "964",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1385",
        "ok": "1385",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1505",
        "ok": "1505",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 10,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.054",
        "ok": "0.054",
        "ko": "-"
    }
}
    },"req_request-97-e0f66": {
        type: "REQUEST",
        name: "request_97",
path: "request_97",
pathFormatted: "req_request-97-e0f66",
stats: {
    "name": "request_97",
    "numberOfRequests": {
        "total": "10",
        "ok": "10",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "721",
        "ok": "721",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1880",
        "ok": "1880",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1055",
        "ok": "1055",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "337",
        "ok": "337",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1060",
        "ok": "1060",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1306",
        "ok": "1306",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1681",
        "ok": "1681",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1840",
        "ok": "1840",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 10,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.054",
        "ok": "0.054",
        "ko": "-"
    }
}
    },"req_request-101-22593": {
        type: "REQUEST",
        name: "request_101",
path: "request_101",
pathFormatted: "req_request-101-22593",
stats: {
    "name": "request_101",
    "numberOfRequests": {
        "total": "10",
        "ok": "9",
        "ko": "1"
    },
    "minResponseTime": {
        "total": "658",
        "ok": "658",
        "ko": "60014"
    },
    "maxResponseTime": {
        "total": "60014",
        "ok": "999",
        "ko": "60014"
    },
    "meanResponseTime": {
        "total": "6720",
        "ok": "798",
        "ko": "60014"
    },
    "standardDeviation": {
        "total": "17765",
        "ok": "95",
        "ko": "0"
    },
    "percentiles1": {
        "total": "865",
        "ok": "859",
        "ko": "60014"
    },
    "percentiles2": {
        "total": "953",
        "ok": "865",
        "ko": "60014"
    },
    "percentiles3": {
        "total": "33457",
        "ok": "946",
        "ko": "60014"
    },
    "percentiles4": {
        "total": "54703",
        "ok": "988",
        "ko": "60014"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 9,
    "percentage": 90
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 1,
    "percentage": 10
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.054",
        "ok": "0.049",
        "ko": "0.005"
    }
}
    },"req_request-99-95d7b": {
        type: "REQUEST",
        name: "request_99",
path: "request_99",
pathFormatted: "req_request-99-95d7b",
stats: {
    "name": "request_99",
    "numberOfRequests": {
        "total": "10",
        "ok": "10",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "586",
        "ok": "586",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1541",
        "ok": "1541",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1088",
        "ok": "1088",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "323",
        "ok": "323",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1422",
        "ok": "1422",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1507",
        "ok": "1507",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1537",
        "ok": "1537",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1540",
        "ok": "1540",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 10,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.054",
        "ok": "0.054",
        "ko": "-"
    }
}
    },"req_request-98-04e4b": {
        type: "REQUEST",
        name: "request_98",
path: "request_98",
pathFormatted: "req_request-98-04e4b",
stats: {
    "name": "request_98",
    "numberOfRequests": {
        "total": "4",
        "ok": "4",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "79",
        "ok": "79",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "961",
        "ok": "961",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "508",
        "ok": "508",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "357",
        "ok": "357",
        "ko": "-"
    },
    "percentiles1": {
        "total": "796",
        "ok": "796",
        "ko": "-"
    },
    "percentiles2": {
        "total": "862",
        "ok": "862",
        "ko": "-"
    },
    "percentiles3": {
        "total": "928",
        "ok": "928",
        "ko": "-"
    },
    "percentiles4": {
        "total": "954",
        "ok": "954",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 4,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.022",
        "ok": "0.022",
        "ko": "-"
    }
}
    },"req_request-90-08ea8": {
        type: "REQUEST",
        name: "request_90",
path: "request_90",
pathFormatted: "req_request-90-08ea8",
stats: {
    "name": "request_90",
    "numberOfRequests": {
        "total": "4",
        "ok": "4",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "513",
        "ok": "513",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1476",
        "ok": "1476",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "975",
        "ok": "975",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "458",
        "ok": "458",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1410",
        "ok": "1410",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1436",
        "ok": "1436",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1463",
        "ok": "1463",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1473",
        "ok": "1473",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 4,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.022",
        "ok": "0.022",
        "ko": "-"
    }
}
    },"req_request-83-20509": {
        type: "REQUEST",
        name: "request_83",
path: "request_83",
pathFormatted: "req_request-83-20509",
stats: {
    "name": "request_83",
    "numberOfRequests": {
        "total": "4",
        "ok": "4",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "399",
        "ok": "399",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1119",
        "ok": "1119",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "723",
        "ok": "723",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "287",
        "ok": "287",
        "ko": "-"
    },
    "percentiles1": {
        "total": "931",
        "ok": "931",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1006",
        "ok": "1006",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1081",
        "ok": "1081",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1111",
        "ok": "1111",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 4,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.022",
        "ok": "0.022",
        "ko": "-"
    }
}
    },"req_request-94-27500": {
        type: "REQUEST",
        name: "request_94",
path: "request_94",
pathFormatted: "req_request-94-27500",
stats: {
    "name": "request_94",
    "numberOfRequests": {
        "total": "4",
        "ok": "4",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "447",
        "ok": "447",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1429",
        "ok": "1429",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "953",
        "ok": "953",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "464",
        "ok": "464",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1410",
        "ok": "1410",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1417",
        "ok": "1417",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1425",
        "ok": "1425",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1428",
        "ok": "1428",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 4,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.022",
        "ok": "0.022",
        "ko": "-"
    }
}
    },"req_request-91-43ae7": {
        type: "REQUEST",
        name: "request_91",
path: "request_91",
pathFormatted: "req_request-91-43ae7",
stats: {
    "name": "request_91",
    "numberOfRequests": {
        "total": "4",
        "ok": "4",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "147",
        "ok": "147",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "687",
        "ok": "687",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "313",
        "ok": "313",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "219",
        "ok": "219",
        "ko": "-"
    },
    "percentiles1": {
        "total": "357",
        "ok": "357",
        "ko": "-"
    },
    "percentiles2": {
        "total": "489",
        "ok": "489",
        "ko": "-"
    },
    "percentiles3": {
        "total": "621",
        "ok": "621",
        "ko": "-"
    },
    "percentiles4": {
        "total": "674",
        "ok": "674",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 4,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.022",
        "ok": "0.022",
        "ko": "-"
    }
}
    },"req_request-95-02d41": {
        type: "REQUEST",
        name: "request_95",
path: "request_95",
pathFormatted: "req_request-95-02d41",
stats: {
    "name": "request_95",
    "numberOfRequests": {
        "total": "4",
        "ok": "4",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "462",
        "ok": "462",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1046",
        "ok": "1046",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "726",
        "ok": "726",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "234",
        "ok": "234",
        "ko": "-"
    },
    "percentiles1": {
        "total": "898",
        "ok": "898",
        "ko": "-"
    },
    "percentiles2": {
        "total": "957",
        "ok": "957",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1016",
        "ok": "1016",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1040",
        "ok": "1040",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 4,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.022",
        "ok": "0.022",
        "ko": "-"
    }
}
    },"req_request-93-dbbcb": {
        type: "REQUEST",
        name: "request_93",
path: "request_93",
pathFormatted: "req_request-93-dbbcb",
stats: {
    "name": "request_93",
    "numberOfRequests": {
        "total": "4",
        "ok": "4",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "315",
        "ok": "315",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "998",
        "ok": "998",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "592",
        "ok": "592",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "251",
        "ok": "251",
        "ko": "-"
    },
    "percentiles1": {
        "total": "661",
        "ok": "661",
        "ko": "-"
    },
    "percentiles2": {
        "total": "796",
        "ok": "796",
        "ko": "-"
    },
    "percentiles3": {
        "total": "930",
        "ok": "930",
        "ko": "-"
    },
    "percentiles4": {
        "total": "984",
        "ok": "984",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 4,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.022",
        "ok": "0.022",
        "ko": "-"
    }
}
    },"req_request-84-ca968": {
        type: "REQUEST",
        name: "request_84",
path: "request_84",
pathFormatted: "req_request-84-ca968",
stats: {
    "name": "request_84",
    "numberOfRequests": {
        "total": "4",
        "ok": "4",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "199",
        "ok": "199",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "453",
        "ok": "453",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "312",
        "ok": "312",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "91",
        "ok": "91",
        "ko": "-"
    },
    "percentiles1": {
        "total": "345",
        "ok": "345",
        "ko": "-"
    },
    "percentiles2": {
        "total": "388",
        "ok": "388",
        "ko": "-"
    },
    "percentiles3": {
        "total": "431",
        "ok": "431",
        "ko": "-"
    },
    "percentiles4": {
        "total": "449",
        "ok": "449",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 4,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.022",
        "ok": "0.022",
        "ko": "-"
    }
}
    },"req_request-85-2b4af": {
        type: "REQUEST",
        name: "request_85",
path: "request_85",
pathFormatted: "req_request-85-2b4af",
stats: {
    "name": "request_85",
    "numberOfRequests": {
        "total": "4",
        "ok": "4",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "205",
        "ok": "205",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "585",
        "ok": "585",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "433",
        "ok": "433",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "140",
        "ok": "140",
        "ko": "-"
    },
    "percentiles1": {
        "total": "503",
        "ok": "503",
        "ko": "-"
    },
    "percentiles2": {
        "total": "536",
        "ok": "536",
        "ko": "-"
    },
    "percentiles3": {
        "total": "569",
        "ok": "569",
        "ko": "-"
    },
    "percentiles4": {
        "total": "582",
        "ok": "582",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 4,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.022",
        "ok": "0.022",
        "ko": "-"
    }
}
    },"req_request-86-1382e": {
        type: "REQUEST",
        name: "request_86",
path: "request_86",
pathFormatted: "req_request-86-1382e",
stats: {
    "name": "request_86",
    "numberOfRequests": {
        "total": "4",
        "ok": "4",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "167",
        "ok": "167",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "490",
        "ok": "490",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "339",
        "ok": "339",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "135",
        "ok": "135",
        "ko": "-"
    },
    "percentiles1": {
        "total": "461",
        "ok": "461",
        "ko": "-"
    },
    "percentiles2": {
        "total": "472",
        "ok": "472",
        "ko": "-"
    },
    "percentiles3": {
        "total": "484",
        "ok": "484",
        "ko": "-"
    },
    "percentiles4": {
        "total": "489",
        "ok": "489",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 4,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.022",
        "ok": "0.022",
        "ko": "-"
    }
}
    },"req_request-87-ba439": {
        type: "REQUEST",
        name: "request_87",
path: "request_87",
pathFormatted: "req_request-87-ba439",
stats: {
    "name": "request_87",
    "numberOfRequests": {
        "total": "4",
        "ok": "4",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "163",
        "ok": "163",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "465",
        "ok": "465",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "287",
        "ok": "287",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "111",
        "ok": "111",
        "ko": "-"
    },
    "percentiles1": {
        "total": "326",
        "ok": "326",
        "ko": "-"
    },
    "percentiles2": {
        "total": "381",
        "ok": "381",
        "ko": "-"
    },
    "percentiles3": {
        "total": "437",
        "ok": "437",
        "ko": "-"
    },
    "percentiles4": {
        "total": "459",
        "ok": "459",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 4,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.022",
        "ok": "0.022",
        "ko": "-"
    }
}
    },"req_request-88-17718": {
        type: "REQUEST",
        name: "request_88",
path: "request_88",
pathFormatted: "req_request-88-17718",
stats: {
    "name": "request_88",
    "numberOfRequests": {
        "total": "4",
        "ok": "4",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "161",
        "ok": "161",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "375",
        "ok": "375",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "254",
        "ok": "254",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "77",
        "ok": "77",
        "ko": "-"
    },
    "percentiles1": {
        "total": "275",
        "ok": "275",
        "ko": "-"
    },
    "percentiles2": {
        "total": "315",
        "ok": "315",
        "ko": "-"
    },
    "percentiles3": {
        "total": "355",
        "ok": "355",
        "ko": "-"
    },
    "percentiles4": {
        "total": "371",
        "ok": "371",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 4,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.022",
        "ok": "0.022",
        "ko": "-"
    }
}
    },"req_request-89-0522e": {
        type: "REQUEST",
        name: "request_89",
path: "request_89",
pathFormatted: "req_request-89-0522e",
stats: {
    "name": "request_89",
    "numberOfRequests": {
        "total": "4",
        "ok": "4",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "159",
        "ok": "159",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "248",
        "ok": "248",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "191",
        "ok": "191",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "34",
        "ok": "34",
        "ko": "-"
    },
    "percentiles1": {
        "total": "198",
        "ok": "198",
        "ko": "-"
    },
    "percentiles2": {
        "total": "218",
        "ok": "218",
        "ko": "-"
    },
    "percentiles3": {
        "total": "238",
        "ok": "238",
        "ko": "-"
    },
    "percentiles4": {
        "total": "246",
        "ok": "246",
        "ko": "-"
    },
    "group1": {
    "name": "t < 3000 ms",
    "count": 4,
    "percentage": 100
},
    "group2": {
    "name": "3000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.022",
        "ok": "0.022",
        "ko": "-"
    }
}
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#percentiles3").append(stat.percentiles3.total);
    $("#percentiles3OK").append(stat.percentiles3.ok);
    $("#percentiles3KO").append(stat.percentiles3.ko);

    $("#percentiles4").append(stat.percentiles4.total);
    $("#percentiles4OK").append(stat.percentiles4.ok);
    $("#percentiles4KO").append(stat.percentiles4.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
